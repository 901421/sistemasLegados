/*
 * test_store.c - unit tests for src/store.c,
 * using real files in build/tmp_store/
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <stdlib.h>
#include "check.h"
#include "../src/store.h"

#define DIR      "build/tmp_store/"
#define TASKS    DIR "tasks.dat"
#define BACKUP   DIR "tasks.bak"
#define TMP      DIR "tasks.dat.tmp"
#define NO_DIR   DIR "missing/tasks.dat"     /* folder that does not exist */

/* Blanks of an empty name, between the date and the description. */
#define NO_NAME  "                    "

static void write_file(const char *path, const char *content)
{
    FILE *f = fopen(path, "wb");

    if (f == NULL) {
        printf("cannot create %s\n", path);
        exit(2);
    }
    fputs(content, f);
    fclose(f);
}

/* Whole file in a static buffer, or NULL if it does not exist. */
static const char *read_file(const char *path)
{
    static char buf[8192];
    size_t n;
    FILE *f = fopen(path, "rb");

    if (f == NULL) {
        return NULL;
    }
    n = fread(buf, 1, sizeof buf - 1, f);
    buf[n] = '\0';
    fclose(f);
    return buf;
}

/* Appends a record and its newline to buf (ASCII names). */
static void put(char *buf, const char *id, char type, const char *date,
                const char *name, const char *description)
{
    sprintf(buf + strlen(buf), "%s %c %s %-20s %s\n", id, type, date,
            name, description);
}

static int exists(const char *path)
{
    return read_file(path) != NULL;
}

static void clean(void)
{
    remove(TASKS);
    remove(BACKUP);
    remove(TMP);
}

static Task new_task(TaskType type, const char *name, const char *description)
{
    Task t;

    t.id = -1;
    t.type = type;
    t.date.year = 2026;
    t.date.month = 10;
    t.date.day = 28;
    strcpy(t.name, name);
    strcpy(t.description, description);
    return t;
}

static void test_missing_file(void)
{
    TaskList list;
    LoadReport report;

    clean();
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 0);
    CHECK_INT(list.next_id, 0);
    CHECK_INT(report.skipped, 0);
    CHECK(!exists(TASKS));          /* loading never creates the file */
    task_list_free(&list);
}

static void test_empty_file(void)
{
    TaskList list;
    LoadReport report;

    clean();
    write_file(TASKS, "");
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 0);
    CHECK_INT(list.next_id, 0);
    task_list_free(&list);
}

static void test_good_file(void)
{
    TaskList list;
    LoadReport report;

    clean();
    /* ids out of order, a "\r\n" line, an empty line, no final newline
       and no control record */
    write_file(TASKS,
               "0000 G 2026-09-28 " NO_NAME " Prueba\n"
               "0005 S 2026-10-01 Imad                 Especifica1\r\n"
               "\n"
               "0002 G 2026-10-15 " NO_NAME " Entregar practica");
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 3);
    CHECK_INT(report.skipped, 0);
    CHECK(!exists(BACKUP));         /* nothing bad, no backup */
    CHECK_INT(list.next_id, 6);     /* highest id + 1 */
    CHECK_INT(list.items[1].id, 5);
    CHECK_STR(list.items[1].name, "Imad");
    CHECK_STR(list.items[1].description, "Especifica1");
    CHECK_STR(list.items[2].description, "Entregar practica");
    task_list_free(&list);
}

/* *NEXT keeps numbers of deleted tasks from being given again. */
static void test_control_record(void)
{
    char content[1024] = "";
    TaskList list;
    LoadReport report;
    Task t;

    clean();
    strcpy(content, "*NEXT 0010\n");
    put(content, "0000", 'G', "2026-09-28", "", "Prueba");
    put(content, "0005", 'S', "2026-10-01", "Imad", "Especifica1");
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 0);
    CHECK_INT(list.count, 2);
    CHECK_INT(list.next_id, 10);
    t = new_task(TASK_GENERAL, "", "Nueva");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 10);
    content[0] = '\0';
    strcpy(content, "*NEXT 0011\n");
    put(content, "0000", 'G', "2026-09-28", "", "Prueba");
    put(content, "0005", 'S', "2026-10-01", "Imad", "Especifica1");
    put(content, "0010", 'G', "2026-10-28", "", "Nueva");
    CHECK_STR(read_file(TASKS), content);
    task_list_free(&list);

    /* a task with a higher number than *NEXT (edited by hand) wins */
    clean();
    strcpy(content, "*NEXT 0003\n");
    put(content, "0007", 'G', "2026-09-28", "", "Prueba");
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.next_id, 8);
    task_list_free(&list);

    /* a bad control record is skipped and reported like a bad line */
    clean();
    strcpy(content, "*NEXT 12a\n*OTHER\n*NEXT 123456\n");
    put(content, "0002", 'G', "2026-09-28", "", "Prueba");
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 3);
    CHECK_INT(report.lines[0].line, 1);
    CHECK_INT(report.lines[0].reason, SKIP_BAD_CONTROL);
    CHECK_INT(report.lines[2].line, 3);
    CHECK(report.backup_made);
    CHECK_INT(list.count, 1);
    CHECK_INT(list.next_id, 3);
    task_list_free(&list);
}

static void test_bad_lines_and_backup(void)
{
    char original[1024] = "";
    char expected[1024] = "";
    TaskList list;
    LoadReport report;
    Task t;

    clean();
    put(original, "0000", 'G', "2026-09-28", "", "Good one");
    put(original, "0001", 'G', "3213      ", "", "Bad date");
    strcat(original, "garbage\n");
    put(original, "0000", 'G', "2026-09-29", "", "Repeated id");
    put(original, "0002", 'S', "2026-09-30", "", "No name");
    put(original, "0003", 'G', "2026-10-01", "", "Good two");
    write_file(TASKS, original);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 2);
    CHECK_INT(list.next_id, 4);
    CHECK_INT(report.skipped, 4);
    CHECK_INT(report.listed, 4);
    CHECK_INT(report.lines[0].line, 2);
    CHECK_INT(report.lines[0].reason, SKIP_BAD_DATE);
    CHECK_INT(report.lines[1].line, 3);
    CHECK_INT(report.lines[1].reason, SKIP_BAD_FIELDS);
    CHECK_INT(report.lines[2].line, 4);
    CHECK_INT(report.lines[2].reason, SKIP_DUPLICATE_ID);
    CHECK_INT(report.lines[3].line, 5);
    CHECK_INT(report.lines[3].reason, SKIP_BAD_NAME);
    CHECK(report.backup_made);
    CHECK(exists(BACKUP) && strcmp(read_file(BACKUP), original) == 0);

    /* saving keeps only the good lines, the backup still has everything */
    t = new_task(TASK_GENERAL, "", "New");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 4);
    strcpy(expected, "*NEXT 0005\n");
    put(expected, "0000", 'G', "2026-09-28", "", "Good one");
    put(expected, "0003", 'G', "2026-10-01", "", "Good two");
    put(expected, "0004", 'G', "2026-10-28", "", "New");
    CHECK_STR(read_file(TASKS), expected);
    CHECK(exists(BACKUP) && strcmp(read_file(BACKUP), original) == 0);
    task_list_free(&list);
}

static void test_many_bad_lines(void)
{
    char content[2048] = "";
    TaskList list;
    LoadReport report;
    int i;

    clean();
    for (i = 0; i < STORE_REPORT_MAX + 5; i++) {
        strcat(content, "bad\n");
    }
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, STORE_REPORT_MAX + 5);    /* all counted */
    CHECK_INT(report.listed, STORE_REPORT_MAX);         /* only the first ones listed */
    CHECK_INT(report.lines[STORE_REPORT_MAX - 1].line, STORE_REPORT_MAX);
    task_list_free(&list);
}

static void test_line_too_long(void)
{
    static char content[TASK_LINE_SIZE * 6];
    TaskList list;
    LoadReport report;
    size_t i;

    clean();
    for (i = 0; i < TASK_LINE_SIZE * 2; i++) {
        content[i] = 'x';
    }
    content[i] = '\0';
    strcat(content, "\n");
    put(content, "0001", 'G', "2026-10-28", "", "After the long one");
    /* a good record followed by more blanks than the buffer holds,
       as a text editor might leave: not too long */
    strcat(content, "0002 G 2026-10-28 " NO_NAME " Blanks after");
    for (i = strlen(content); i < TASK_LINE_SIZE * 5; i++) {
        content[i] = ' ';
    }
    content[i] = '\0';
    strcat(content, "\n");
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 1);
    CHECK_INT(report.lines[0].line, 1);
    CHECK_INT(report.lines[0].reason, SKIP_TOO_LONG);
    CHECK_INT(list.count, 2);                           /* next lines read fine */
    CHECK_STR(list.items[0].description, "After the long one");
    CHECK_STR(list.items[1].description, "Blanks after");
    task_list_free(&list);
}

static void test_backup_fails(void)
{
    char original[256] = "";
    TaskList list;
    LoadReport report;
    Task t;

    clean();
    put(original, "0000", 'G', "2026-09-28", "", "Good");
    strcat(original, "bad\n");
    write_file(TASKS, original);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, NO_DIR, &list, &report), STORE_ERR_BACKUP);
    CHECK_INT(list.count, 1);       /* good tasks are still shown */
    CHECK(list.read_only);
    t = new_task(TASK_GENERAL, "", "New");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_ERR_READ_ONLY);
    CHECK_INT(store_save(TASKS, &list), STORE_ERR_READ_ONLY);
    CHECK_INT(list.count, 1);
    CHECK_STR(read_file(TASKS), original);              /* untouched */
    task_list_free(&list);
}

static void test_numbering_survives_restart(void)
{
    TaskList list;
    LoadReport report;
    Task t;

    clean();
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    t = new_task(TASK_GENERAL, "", "First session");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 0);
    t = new_task(TASK_SPECIFIC, "Ana Lopez", "Pipe | and \\ inside");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 1);
    task_list_free(&list);
    CHECK(!exists(TMP));            /* temporary file renamed away */
    CHECK(strncmp(read_file(TASKS), "*NEXT 0002\n", 11) == 0);

    /* second "session": same tasks, numbering goes on */
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 2);
    CHECK_STR(list.items[1].name, "Ana Lopez");
    CHECK_STR(list.items[1].description, "Pipe | and \\ inside");
    t = new_task(TASK_GENERAL, "", "Second session");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 2);
    task_list_free(&list);
}

static void test_save_fails_rolls_back(void)
{
    TaskList list;
    Task t;

    task_list_init(&list);
    t = new_task(TASK_GENERAL, "", "Cannot be written");
    CHECK_INT(store_add_and_save(NO_DIR, &list, &t), STORE_ERR_WRITE);
    CHECK_INT(list.count, 0);       /* not saved, so not in the list */
    CHECK_INT(list.next_id, 0);     /* number not used up */
    task_list_free(&list);
}

static void test_add_checks(void)
{
    TaskList list;
    LoadReport report;
    Task t;
    int i;

    task_list_init(&list);
    t = new_task(TASK_SPECIFIC, "", "Specific without name");
    CHECK_INT(task_list_add(&list, &t), STORE_ERR_INVALID);
    CHECK_INT(t.id, -1);
    CHECK_INT(list.count, 0);

    for (i = 0; i < 100; i++) {     /* forces several reallocs */
        t = new_task(TASK_GENERAL, "", "Many");
        CHECK_INT(task_list_add(&list, &t), STORE_OK);
    }
    CHECK_INT(list.count, 100);
    CHECK_INT(list.items[99].id, 99);
    task_list_free(&list);

    /* the last number, 9999, and then no more, also after a restart */
    clean();
    task_list_init(&list);
    list.next_id = TASK_ID_MAX;
    t = new_task(TASK_GENERAL, "", "Last number");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 9999);
    t = new_task(TASK_GENERAL, "", "No numbers left");
    CHECK_INT(task_list_add(&list, &t), STORE_ERR_FULL);
    CHECK_INT(list.count, 1);
    task_list_free(&list);
    CHECK(list.items == NULL && list.count == 0);
    CHECK(strncmp(read_file(TASKS), "*NEXT 10000\n", 12) == 0);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 0);
    CHECK_INT(list.next_id, TASK_ID_MAX + 1);
    task_list_free(&list);
}

static void test_cannot_open(void)
{
    TaskList list;
    LoadReport report;

    /* a directory with the file's name: fopen works on Linux but reading fails */
    task_list_init(&list);
    CHECK(store_load(DIR, BACKUP, &list, &report) != STORE_OK);
    CHECK_INT(list.count, 0);
    task_list_free(&list);
}

/* MUSIC/SP gives every record back padded with blanks up to 80. */
static void test_padded_records(void)
{
    char content[1024] = "";
    char line[TASK_LINE_SIZE];
    TaskList list;
    LoadReport report;

    clean();
    sprintf(content, "%-80s\n", "*NEXT 0004");
    sprintf(line, "0000 G 2026-09-28 %-20s %s", "", "Prueba");
    sprintf(content + strlen(content), "%-80s\n", line);
    sprintf(line, "0001 S 2026-10-01 %-20s %s", "Imad", "Una descripcion");
    sprintf(content + strlen(content), "%-80s\n", line);
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 0);
    CHECK_INT(list.count, 2);
    CHECK_INT(list.next_id, 4);
    CHECK_STR(list.items[0].description, "Prueba");
    CHECK_STR(list.items[1].name, "Imad");
    CHECK_STR(list.items[1].description, "Una descripcion");
    task_list_free(&list);
}

/* The longest task is saved in one record of less than 80 characters
   and read back the same. */
static void test_long_task_round_trip(void)
{
    TaskList list;
    LoadReport report;
    Task t = new_task(TASK_SPECIFIC, "a|b|c|d|e|f|g|h|i|j|",
                      "\\1234567890\\1234567890\\123456789|1234567");
    const char *text;
    size_t lines = 0, longest = 0, len = 0;

    clean();
    task_list_init(&list);
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    task_list_free(&list);

    text = read_file(TASKS);
    CHECK(text != NULL);
    for (; text != NULL && *text != '\0'; text++) {
        if (*text == '\n') {
            lines++;
            len = 0;
        } else if (++len > longest) {
            longest = len;
        }
    }
    CHECK_INT(lines, 2);            /* *NEXT and the task */
    CHECK_INT(longest, 79);

    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(report.skipped, 0);
    CHECK_INT(list.count, 1);
    CHECK_STR(list.items[0].name, "a|b|c|d|e|f|g|h|i|j|");
    CHECK_STR(list.items[0].description,
              "\\1234567890\\1234567890\\123456789|1234567");
    task_list_free(&list);
}

/* Deleting rewrites the file without the task; its number is never
   given again, not even after a restart. */
static void test_delete(void)
{
    char content[1024] = "";
    char expected[1024] = "";
    TaskList list;
    LoadReport report;
    Task t;

    clean();
    strcpy(content, "*NEXT 0004\n");
    put(content, "0000", 'G', "2026-09-28", "", "Zero");
    put(content, "0002", 'S', "2026-10-01", "Imad", "Two");
    put(content, "0001", 'G', "2026-10-02", "", "One");
    put(content, "0003", 'G', "2026-10-03", "", "Three");
    write_file(TASKS, content);
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);

    CHECK(task_list_find(&list, 2) != NULL);
    CHECK(task_list_find(&list, 9) == NULL);
    CHECK_INT(store_delete_and_save(TASKS, &list, 9), STORE_ERR_NOT_FOUND);
    CHECK_STR(read_file(TASKS), content);           /* untouched */

    CHECK_INT(store_delete_and_save(TASKS, &list, 2), STORE_OK);
    CHECK_INT(list.count, 3);
    CHECK(task_list_find(&list, 2) == NULL);
    CHECK_INT(list.items[1].id, 1);                 /* order kept */
    /* the highest one too */
    CHECK_INT(store_delete_and_save(TASKS, &list, 3), STORE_OK);
    CHECK_INT(list.next_id, 4);
    strcpy(expected, "*NEXT 0004\n");
    put(expected, "0000", 'G', "2026-09-28", "", "Zero");
    put(expected, "0001", 'G', "2026-10-02", "", "One");
    CHECK_STR(read_file(TASKS), expected);
    CHECK(!exists(TMP));
    task_list_free(&list);

    /* restart: the next number is 4, not 2 or 3 */
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, BACKUP, &list, &report), STORE_OK);
    CHECK_INT(list.count, 2);
    t = new_task(TASK_GENERAL, "", "After deleting");
    CHECK_INT(store_add_and_save(TASKS, &list, &t), STORE_OK);
    CHECK_INT(t.id, 4);

    /* deleting every task leaves only the control record */
    CHECK_INT(store_delete_and_save(TASKS, &list, 0), STORE_OK);
    CHECK_INT(store_delete_and_save(TASKS, &list, 1), STORE_OK);
    CHECK_INT(store_delete_and_save(TASKS, &list, 4), STORE_OK);
    CHECK_INT(list.count, 0);
    CHECK_STR(read_file(TASKS), "*NEXT 0005\n");
    task_list_free(&list);
}

/* A failed save puts the task back in its place. */
static void test_delete_fails_rolls_back(void)
{
    TaskList list;
    LoadReport report;
    Task t;
    int i;

    task_list_init(&list);
    for (i = 0; i < 3; i++) {
        t = new_task(TASK_GENERAL, "", "Kept");
        CHECK_INT(task_list_add(&list, &t), STORE_OK);
    }
    CHECK_INT(store_delete_and_save(NO_DIR, &list, 1), STORE_ERR_WRITE);
    CHECK_INT(list.count, 3);
    CHECK_INT(list.items[0].id, 0);
    CHECK_INT(list.items[1].id, 1);
    CHECK_INT(list.items[2].id, 2);
    task_list_free(&list);

    /* read only (backup failed at load): nothing is deleted */
    clean();
    write_file(TASKS, "0000 G 2026-09-28 " NO_NAME " Good\nbad\n");
    task_list_init(&list);
    CHECK_INT(store_load(TASKS, NO_DIR, &list, &report), STORE_ERR_BACKUP);
    CHECK_INT(store_delete_and_save(TASKS, &list, 0), STORE_ERR_READ_ONLY);
    CHECK_INT(list.count, 1);
    task_list_free(&list);
}

static void test_texts(void)
{
    CHECK_STR(store_status_text(STORE_ERR_WRITE), "ERROR WRITING THE TASK FILE");
    CHECK_STR(store_skip_text(SKIP_DUPLICATE_ID), "REPEATED TASK NUMBER");
    CHECK_STR(store_skip_text(SKIP_BAD_CONTROL), "BAD *NEXT RECORD");
    CHECK_STR(store_status_text(STORE_ERR_NOT_FOUND), "NO TASK WITH THAT NUMBER");
}

int main(void)
{
    test_missing_file();
    test_empty_file();
    test_good_file();
    test_control_record();
    test_bad_lines_and_backup();
    test_many_bad_lines();
    test_line_too_long();
    test_backup_fails();
    test_numbering_survives_restart();
    test_save_fails_rolls_back();
    test_add_checks();
    test_cannot_open();
    test_padded_records();
    test_long_task_round_trip();
    test_delete();
    test_delete_fails_rolls_back();
    test_texts();
    clean();
    return CHECK_SUMMARY();
}
