#!/usr/bin/env bash
# Integration tests: runs build/tasks on every case in tests/integration/ and
# compares the screen and the files left behind with the expected ones.
#
#   tests/run_integration.sh            run every case
#   tests/run_integration.sh --update CASE
#                                       write expected.* of that one case from the
#                                       current output (to create it; then review it
#                                       by hand). Never updates more than one case.
#
# Each case folder holds:
#   input.txt       what is typed
#   tasks.before    tasks.dat at start (optional)
#   expected.out    the whole screen in --plain mode
#   expected.tasks  tasks.dat at the end (if missing, tasks.dat must not exist)
#   expected.bak    tasks.bak at the end (if missing, tasks.bak must not exist)
#
# Every case runs in its own empty folder with the default file name, and with
# a fixed "today" so the result does not depend on the day it is run.
#
# Author: Imad Habib Jali (NIP 901421)

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PROGRAM="${PROGRAM:-$ROOT/build/tasks}"   # PROGRAM=...: test another build
CASES="$ROOT/tests/integration"
WORK="$ROOT/build/integration"
TODAY="06/10/2026"
MAX_WIDTH=80
UPDATE_CASE=""
if [ "$1" = "--update" ]; then
    UPDATE_CASE="$2"
    [ -n "$UPDATE_CASE" ] && [ -d "$CASES/$UPDATE_CASE" ] \
        || { echo "usage: $0 --update CASE (one of: $(ls "$CASES" | tr '\n' ' '))"; exit 2; }
fi

[ -x "$PROGRAM" ] || { echo "missing $PROGRAM (run make)"; exit 2; }
# Absolute path: every case runs inside its own folder.
PROGRAM="$(cd "$(dirname "$PROGRAM")" && pwd)/$(basename "$PROGRAM")"

passed=0
failed=0

# Compares the produced file $2 with the expected $1; a missing expected file
# means the produced one must not exist either.
compare(){
    local expected="$1" produced="$2" what="$3"
    if [ "$UPDATE" = 1 ]; then
        if [ -e "$produced" ]; then cp "$produced" "$expected"; else rm -f "$expected"; fi
        return 0
    fi
    if [ -e "$expected" ]; then
        [ -e "$produced" ] || { echo "    $what: expected but not created"; return 1; }
        diff -u "$expected" "$produced" > "$produced.diff" || { echo "    $what differs:"; sed 's/^/      /' "$produced.diff" | head -40; return 1; }
    elif [ -e "$produced" ]; then
        echo "    $what: created but not expected"; return 1
    fi
    return 0
}

for dir in "$CASES"/*/; do
    name=$(basename "$dir")
    UPDATE=0
    [ "$name" = "$UPDATE_CASE" ] && UPDATE=1
    work="$WORK/$name"
    rm -rf "$work"; mkdir -p "$work"
    [ -e "$dir/tasks.before" ] && cp "$dir/tasks.before" "$work/tasks.dat"

    (cd "$work" && "$PROGRAM" --plain --today "$TODAY" < "$dir/input.txt" > screen.out 2> stderr.out)
    code=$?

    ok=1
    [ "$code" = 0 ] || { echo "    exit code $code"; ok=0; }
    [ -s "$work/stderr.out" ] && { echo "    wrote to stderr:"; cat "$work/stderr.out"; ok=0; }
    compare "$dir/expected.out" "$work/screen.out" "screen" || ok=0
    compare "$dir/expected.tasks" "$work/tasks.dat" "tasks.dat" || ok=0
    compare "$dir/expected.bak" "$work/tasks.bak" "tasks.bak" || ok=0
    [ -e "$work/tasks.dat.tmp" ] && { echo "    tasks.dat.tmp left behind"; ok=0; }

    # No screen line wider than 80 characters (counted as characters, not bytes).
    width=$(LC_ALL=C.UTF-8 wc -L < "$work/screen.out")
    [ "$width" -le "$MAX_WIDTH" ] || { echo "    a line is $width characters wide"; ok=0; }

    if [ "$ok" = 1 ]; then
        passed=$((passed + 1))
        [ "$UPDATE" = 1 ] && echo "updated $name" || echo "ok      $name"
    else
        failed=$((failed + 1))
        echo "FAILED  $name"
    fi
done

echo "tests/run_integration.sh: $((passed + failed)) cases, $failed failed"
[ "$failed" = 0 ]
