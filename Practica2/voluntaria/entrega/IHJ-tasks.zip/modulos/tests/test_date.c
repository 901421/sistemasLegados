/*
 * test_date.c - unit tests for src/date.c
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include "check.h"
#include "../src/date.h"

/* Parses text with default year 2026 and returns the status; fills *d on success. */
static DateStatus parse(const char *text, Date *d)
{
    d->year = d->month = d->day = -1;
    return date_parse(text, 2026, d);
}

static void test_leap_years(void)
{
    CHECK(date_is_leap(2024));
    CHECK(date_is_leap(2000));          /* divisible by 400 */
    CHECK(!date_is_leap(1900));         /* divisible by 100, not by 400 */
    CHECK(!date_is_leap(2026));
}

static void test_days_in_month(void)
{
    CHECK_INT(date_days_in_month(2026, 1), 31);
    CHECK_INT(date_days_in_month(2026, 2), 28);
    CHECK_INT(date_days_in_month(2024, 2), 29);
    CHECK_INT(date_days_in_month(2026, 4), 30);
    CHECK_INT(date_days_in_month(2026, 12), 31);
    CHECK_INT(date_days_in_month(2026, 0), 0);
    CHECK_INT(date_days_in_month(2026, 13), 0);
}

static void test_parse_full(void)
{
    Date d;

    CHECK_INT(parse("28/10/2026", &d), DATE_OK);
    CHECK_INT(d.day, 28);
    CHECK_INT(d.month, 10);
    CHECK_INT(d.year, 2026);

    CHECK_INT(parse("5/3/2027", &d), DATE_OK);     /* one-digit day and month */
    CHECK_INT(d.day, 5);
    CHECK_INT(d.month, 3);
    CHECK_INT(d.year, 2027);

    CHECK_INT(parse("29/02/2024", &d), DATE_OK);   /* leap year */
    CHECK_INT(parse("31/12/2999", &d), DATE_OK);   /* upper limit */
    CHECK_INT(parse("01/01/1900", &d), DATE_OK);   /* lower limit */
}

static void test_parse_shortcuts(void)
{
    Date d;

    CHECK_INT(parse("28/10", &d), DATE_OK);
    CHECK_INT(d.day, 28);
    CHECK_INT(d.month, 10);
    CHECK_INT(d.year, 2026);                        /* default year */

    CHECK_INT(parse("2809", &d), DATE_OK);          /* DDMM, as in the original */
    CHECK_INT(d.day, 28);
    CHECK_INT(d.month, 9);
    CHECK_INT(d.year, 2026);

    CHECK_INT(parse("0110", &d), DATE_OK);          /* leading zero */
    CHECK_INT(d.day, 1);
    CHECK_INT(d.month, 10);
}

/* Dates that tareas.c stored without checking. */
static void test_original_bad_dates(void)
{
    Date d;

    CHECK_INT(parse("3213", &d), DATE_ERR_INVALID);   /* day 32, month 13 */
    CHECK_INT(parse("12345", &d), DATE_ERR_FORMAT);   /* five digits */
    CHECK_INT(parse("ab12", &d), DATE_ERR_FORMAT);    /* letters */
    CHECK_INT(parse("", &d), DATE_ERR_FORMAT);        /* empty */
}

static void test_parse_invalid_days(void)
{
    Date d;

    CHECK_INT(parse("29/02/2026", &d), DATE_ERR_INVALID);  /* not a leap year */
    CHECK_INT(parse("29/02/1900", &d), DATE_ERR_INVALID);
    CHECK_INT(parse("31/04/2026", &d), DATE_ERR_INVALID);  /* April has 30 */
    CHECK_INT(parse("00/10/2026", &d), DATE_ERR_INVALID);
    CHECK_INT(parse("10/00/2026", &d), DATE_ERR_INVALID);
    CHECK_INT(parse("0000", &d), DATE_ERR_INVALID);
    CHECK_INT(parse("31/12/1899", &d), DATE_ERR_INVALID);  /* below DATE_MIN_YEAR */
    CHECK_INT(parse("01/01/3000", &d), DATE_ERR_INVALID);  /* above DATE_MAX_YEAR */
}

static void test_parse_bad_format(void)
{
    Date d;

    CHECK_INT(parse("28-10-2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("28/10/26", &d), DATE_ERR_FORMAT);     /* two-digit year */
    CHECK_INT(parse("28/10/20266", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("281/10/2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("28/101/2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("28/10/", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("/10/2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("28//2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("28", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("281", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse(" 28/10/2026", &d), DATE_ERR_FORMAT);  /* trimming is the input layer's job */
    CHECK_INT(parse("28/10/2026 ", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("+2/10/2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(parse("-2/10/2026", &d), DATE_ERR_FORMAT);
    CHECK_INT(date_parse(NULL, 2026, &d), DATE_ERR_FORMAT);
}

static void test_out_untouched_on_error(void)
{
    Date d;

    d.year = 1;
    d.month = 2;
    d.day = 3;
    CHECK_INT(date_parse("31/04/2026", 2026, &d), DATE_ERR_INVALID);
    CHECK_INT(d.year, 1);
    CHECK_INT(d.month, 2);
    CHECK_INT(d.day, 3);
}

static void test_iso_round_trip(void)
{
    Date d, back;
    char buf[DATE_TEXT_SIZE];

    d.year = 2026;
    d.month = 3;
    d.day = 5;
    CHECK_STR(date_to_iso(&d, buf), "2026-03-05");
    CHECK_STR(date_to_display(&d, buf), "05/03/2026");

    CHECK_INT(date_from_iso("2026-03-05", &back), DATE_OK);
    CHECK_INT(date_compare(&d, &back), 0);

    CHECK_INT(date_from_iso("2026-02-29", &back), DATE_ERR_INVALID);
    CHECK_INT(date_from_iso("2026-3-05", &back), DATE_ERR_FORMAT);
    CHECK_INT(date_from_iso("05/03/2026", &back), DATE_ERR_FORMAT);
    CHECK_INT(date_from_iso("2026-03-05x", &back), DATE_ERR_FORMAT);
    CHECK_INT(date_from_iso("", &back), DATE_ERR_FORMAT);
}

static void test_compare(void)
{
    Date a, b;

    a.year = 2026; a.month = 10; a.day = 28;
    b = a;
    CHECK(date_compare(&a, &b) == 0);
    b.day = 29;
    CHECK(date_compare(&a, &b) < 0);
    b.day = 1; b.month = 11;
    CHECK(date_compare(&a, &b) < 0);
    b.month = 1; b.year = 2027;
    CHECK(date_compare(&a, &b) < 0);
    CHECK(date_compare(&b, &a) > 0);
}

static void test_today(void)
{
    Date d;

    CHECK(date_today(&d));
    CHECK(date_is_valid(&d));
}

int main(void)
{
    test_leap_years();
    test_days_in_month();
    test_parse_full();
    test_parse_shortcuts();
    test_original_bad_dates();
    test_parse_invalid_days();
    test_parse_bad_format();
    test_out_untouched_on_error();
    test_iso_round_trip();
    test_compare();
    test_today();
    return CHECK_SUMMARY();
}
