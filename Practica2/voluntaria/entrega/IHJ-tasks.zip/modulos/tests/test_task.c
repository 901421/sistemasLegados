/*
 * test_task.c - unit tests for src/task.c
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include "check.h"
#include "../src/task.h"

static Task make_task(long id, TaskType type, const char *name, const char *description)
{
    Task t;

    t.id = id;
    t.type = type;
    t.date.year = 2026;
    t.date.month = 10;
    t.date.day = 28;
    strcpy(t.name, name);
    strcpy(t.description, description);
    return t;
}

/* A record built field by field, for ASCII names: "%-20s" pads
   bytes, which are characters there. */
static const char *rec(const char *id, char type, const char *date,
                       const char *name, const char *description)
{
    static char buf[TASK_LINE_SIZE];

    sprintf(buf, "%s %c %s %-20s %s", id, type, date, name, description);
    return buf;
}

/* Formats t and parses it back; checks every field survives the trip. */
static void check_round_trip(const Task *t, const char *expected_line)
{
    char line[TASK_LINE_SIZE];
    Task back;

    CHECK(task_format_line(t, line, sizeof line));
    CHECK_STR(line, expected_line);
    CHECK_INT(task_parse_line(line, &back), LINE_OK);
    CHECK_INT(back.id, t->id);
    CHECK_INT(back.type, t->type);
    CHECK_INT(date_compare(&back.date, &t->date), 0);
    CHECK_STR(back.name, t->name);
    CHECK_STR(back.description, t->description);
}

static void test_text_length(void)
{
    CHECK_INT(task_text_length(""), 0);
    CHECK_INT(task_text_length("Prueba"), 6);
    CHECK_INT(task_text_length("Cami\xC3\xB3n"), 6);          /* "Camión": 7 bytes, 6 chars */
    CHECK_INT(task_text_length("Espa\xC3\xB1" "a"), 6);       /* "España" */
    CHECK_INT(task_text_length("\xE2\x82\xAC"), 1);           /* euro sign, 3 bytes */
}

static void test_check_text(void)
{
    CHECK_INT(task_check_text("Prueba grupo 02", 50), TEXT_OK);   /* spaces: lost in the original */
    CHECK_INT(task_check_text("", 50), TEXT_EMPTY);
    CHECK_INT(task_check_text("   ", 50), TEXT_EMPTY);
    CHECK_INT(task_check_text("a\tb", 50), TEXT_BAD_CHAR);
    CHECK_INT(task_check_text("a\nb", 50), TEXT_BAD_CHAR);
    CHECK_INT(task_check_text("a|b\\c", 50), TEXT_OK);            /* stored as it is */
}

/* Fills buf with count copies of the byte sequence piece. */
static char *repeat(char *buf, const char *piece, int count)
{
    int i;

    buf[0] = '\0';
    for (i = 0; i < count; i++) {
        strcat(buf, piece);
    }
    return buf;
}

static void test_check_text_limits(void)
{
    char buf[TASK_DESC_SIZE + 8];

    CHECK_INT(task_check_text(repeat(buf, "n", TASK_NAME_MAX), TASK_NAME_MAX), TEXT_OK);
    CHECK_INT(task_check_text(repeat(buf, "n", TASK_NAME_MAX + 1), TASK_NAME_MAX), TEXT_TOO_LONG);
    CHECK_INT(task_check_text(repeat(buf, "d", TASK_DESC_MAX), TASK_DESC_MAX), TEXT_OK);
    CHECK_INT(task_check_text(repeat(buf, "d", TASK_DESC_MAX + 1), TASK_DESC_MAX), TEXT_TOO_LONG);
    /* 20 "\xC3\xB1" (ñ): 40 bytes but 20 characters, allowed */
    CHECK_INT(task_check_text(repeat(buf, "\xC3\xB1", TASK_NAME_MAX), TASK_NAME_MAX), TEXT_OK);
    CHECK_INT(task_check_text(repeat(buf, "\xC3\xB1", TASK_NAME_MAX + 1), TASK_NAME_MAX), TEXT_TOO_LONG);
    /* TASK_DESC_MAX four-byte characters: the biggest description in bytes */
    CHECK_INT(task_check_text(repeat(buf, "\xF0\x9F\x98\x80", TASK_DESC_MAX), TASK_DESC_MAX), TEXT_OK);
    /* Bad UTF-8: one lead byte and many continuation bytes counts as 1 character
       but would not fit in the task buffer. */
    {
        char bad[TASK_DESC_SIZE + 8];

        bad[0] = '\xC3';
        memset(bad + 1, '\x80', TASK_DESC_SIZE + 5);
        bad[TASK_DESC_SIZE + 6] = '\0';
        CHECK_INT(task_text_length(bad), 1);
        CHECK_INT(task_check_text(bad, TASK_DESC_MAX), TEXT_TOO_LONG);
    }
}

static void test_truncate_text(void)
{
    char buf[TASK_DESC_SIZE + 64];

    strcpy(buf, "Short");
    CHECK(!task_truncate_text(buf, TASK_NAME_MAX));     /* nothing cut */
    CHECK_STR(buf, "Short");
    repeat(buf, "n", TASK_NAME_MAX);
    CHECK(!task_truncate_text(buf, TASK_NAME_MAX));     /* exactly 20 */
    CHECK_INT(strlen(buf), TASK_NAME_MAX);
    repeat(buf, "n", TASK_NAME_MAX + 1);
    CHECK(task_truncate_text(buf, TASK_NAME_MAX));      /* 21 -> 20 */
    CHECK_STR(buf, repeat(buf + 32, "n", TASK_NAME_MAX));
    repeat(buf, "d", TASK_DESC_MAX + 10);
    CHECK(task_truncate_text(buf, TASK_DESC_MAX));
    CHECK_INT(task_text_length(buf), TASK_DESC_MAX);
    /* 21 "ñ": cut after the 20th, never inside one */
    repeat(buf, "\xC3\xB1", TASK_NAME_MAX + 1);
    CHECK(task_truncate_text(buf, TASK_NAME_MAX));
    CHECK_INT(strlen(buf), 2 * TASK_NAME_MAX);
    CHECK_INT(task_check_text(buf, TASK_NAME_MAX), TEXT_OK);
    /* blanks left at the end of the cut are dropped */
    strcpy(buf, "1234567890123456789 x");
    CHECK(task_truncate_text(buf, TASK_NAME_MAX));
    CHECK_STR(buf, "1234567890123456789");
    /* bad UTF-8, 1 character of many bytes: cut by bytes too */
    buf[0] = '\xC3';
    memset(buf + 1, '\x80', TASK_NAME_MAX * 4 + 10);
    buf[TASK_NAME_MAX * 4 + 11] = '\0';
    CHECK(task_truncate_text(buf, TASK_NAME_MAX));
    CHECK(strlen(buf) <= TASK_NAME_MAX * 4);
}

static void test_round_trip(void)
{
    Task t;

    t = make_task(0, TASK_GENERAL, "", "Buy milk");
    check_round_trip(&t, "0000 G 2026-10-28                      Buy milk");

    t = make_task(3, TASK_SPECIFIC, "Ana Lopez", "Review the report");  /* spaces in both */
    check_round_trip(&t, "0003 S 2026-10-28 Ana Lopez            Review the report");
    CHECK_STR(rec("0003", 'S', "2026-10-28", "Ana Lopez", "Review the report"),
              "0003 S 2026-10-28 Ana Lopez            Review the report");

    t = make_task(7, TASK_SPECIFIC, "a|b", "c\\d|");                    /* no escaping now */
    check_round_trip(&t, rec("0007", 'S', "2026-10-28", "a|b", "c\\d|"));

    /* "Camión": the description starts in the same column; a UTF-8 name
       is padded by characters, not bytes */
    t = make_task(12, TASK_SPECIFIC, "Cami\xC3\xB3n", "Cami\xC3\xB3n");
    check_round_trip(&t, "0012 S 2026-10-28 Cami\xC3\xB3n               Cami\xC3\xB3n");

    t = make_task(TASK_ID_MAX, TASK_GENERAL, "", "Last id");
    check_round_trip(&t, rec("9999", 'G', "2026-10-28", "", "Last id"));
}

static void test_format_rejects(void)
{
    char line[TASK_LINE_SIZE];
    char small[10];
    Task t;

    t = make_task(1, TASK_GENERAL, "Someone", "General with name");
    CHECK(!task_format_line(&t, line, sizeof line));

    t = make_task(1, TASK_SPECIFIC, "", "Specific without name");
    CHECK(!task_format_line(&t, line, sizeof line));

    t = make_task(-1, TASK_GENERAL, "", "Negative id");
    CHECK(!task_format_line(&t, line, sizeof line));

    t = make_task(TASK_ID_MAX + 1, TASK_GENERAL, "", "Five digits");
    CHECK(!task_format_line(&t, line, sizeof line));

    t = make_task(1, TASK_GENERAL, "", "Too small buffer");
    CHECK(!task_format_line(&t, small, sizeof small));
    CHECK(!task_format_line(&t, line, 0));
    /* exact fit: 39 columns before the description, 16 for it, '\0' */
    CHECK(task_format_line(&t, line, 39 + 16 + 1));
    CHECK(!task_format_line(&t, line, 39 + 16));
}

/* The longest record: 79 characters, so it fits in a record of 80; and
   in bytes, with 4-byte characters, it fits in TASK_LINE_SIZE. */
static void test_longest_line_fits(void)
{
    char line[TASK_LINE_SIZE];
    Task t;

    t = make_task(TASK_ID_MAX, TASK_SPECIFIC, "", "");
    repeat(t.name, "|", TASK_NAME_MAX);
    repeat(t.description, "\\", TASK_DESC_MAX);
    CHECK(task_format_line(&t, line, sizeof line));
    CHECK_INT(strlen(line), TASK_RECORD_CHARS);
    CHECK_INT(TASK_RECORD_CHARS, 79);

    repeat(t.name, "\xF0\x9F\x98\x80", TASK_NAME_MAX);
    repeat(t.description, "\xF0\x9F\x98\x80", TASK_DESC_MAX);
    CHECK(task_format_line(&t, line, sizeof line));
    CHECK_INT(task_text_length(line), TASK_RECORD_CHARS);
    CHECK_INT(strlen(line) + 1, TASK_LINE_SIZE);
}

static void test_parse_bad_lines(void)
{
    char name21[32];
    Task t;

    t = make_task(99, TASK_GENERAL, "", "untouched");
    CHECK_INT(task_parse_line("", &t), LINE_BAD_FIELDS);
    CHECK_INT(task_parse_line("0000 G 2026-10-2", &t), LINE_BAD_FIELDS);    /* too short */
    CHECK_INT(task_parse_line("0000|G 2026-10-28 ", &t), LINE_BAD_FIELDS);  /* column 5 */
    CHECK_INT(task_parse_line("0000 G|2026-10-28 ", &t), LINE_BAD_FIELDS);  /* column 7 */
    CHECK_INT(task_parse_line("0000 G 2026-10-28|", &t), LINE_BAD_FIELDS);  /* column 18 */
    CHECK_INT(task_parse_line(rec("x000", 'G', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_ID);
    CHECK_INT(task_parse_line(rec("-001", 'G', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_ID);
    CHECK_INT(task_parse_line(rec(" 001", 'G', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_ID);
    CHECK_INT(task_parse_line("00001 G 2026-10-28                      Buy", &t), LINE_BAD_FIELDS);
    CHECK_INT(task_parse_line(rec("0000", 'g', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_TYPE);
    CHECK_INT(task_parse_line(rec("0000", 'X', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_TYPE);
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-02-29", "", "Buy milk"), &t), LINE_BAD_DATE);
    CHECK_INT(task_parse_line(rec("0000", 'G', "28/10/2026", "", "Buy milk"), &t), LINE_BAD_DATE);
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-10-28", "Ana", "Buy milk"), &t), LINE_BAD_NAME);
    CHECK_INT(task_parse_line(rec("0000", 'S', "2026-10-28", "", "Buy milk"), &t), LINE_BAD_NAME);
    /* a name one column to the right */
    CHECK_INT(task_parse_line(rec("0000", 'S', "2026-10-28", " Ana", "Buy"), &t), LINE_BAD_NAME);
    /* a name of 21 characters runs into the blank column 39 */
    repeat(name21, "n", 21);
    CHECK_INT(task_parse_line(rec("0000", 'S', "2026-10-28", name21, "Buy"), &t), LINE_BAD_FIELDS);
    /* a description one column to the right, or missing */
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-10-28", "", " Buy milk"), &t), LINE_BAD_DESCRIPTION);
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-10-28", "", ""), &t), LINE_BAD_DESCRIPTION);
    CHECK_INT(task_parse_line("0000 G 2026-10-28 ", &t), LINE_BAD_DESCRIPTION);
    /* 41 characters of description */
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-10-28", "",
                                  "12345678901234567890123456789012345678901"), &t),
              LINE_BAD_DESCRIPTION);
    CHECK_INT(task_parse_line(rec("0000", 'G', "2026-10-28", "", "Tab\there"), &t),
              LINE_BAD_DESCRIPTION);
    CHECK_INT(task_parse_line(NULL, &t), LINE_BAD_FIELDS);
    /* *out not written on error */
    CHECK_INT(t.id, 99);
    CHECK_STR(t.description, "untouched");
}

/* Lines written by hand: blanks at the end of a short name, and a
   specific task whose record ends right after the name. */
static void test_parse_by_hand(void)
{
    Task t;

    CHECK_INT(task_parse_line(rec("0042", 'S', "2026-10-28", "Paula", "Repasar"), &t), LINE_OK);
    CHECK_INT(t.id, 42);
    CHECK_STR(t.name, "Paula");
    CHECK_STR(t.description, "Repasar");
    /* "|" and "\" are plain characters */
    CHECK_INT(task_parse_line(rec("0001", 'G', "2026-10-28", "", "a|b\\c"), &t), LINE_OK);
    CHECK_STR(t.description, "a|b\\c");
}

static void test_type_name(void)
{
    CHECK_STR(task_type_name(TASK_GENERAL), "GENERAL");
    CHECK_STR(task_type_name(TASK_SPECIFIC), "SPECIFIC");
}

int main(void)
{
    test_text_length();
    test_check_text();
    test_check_text_limits();
    test_truncate_text();
    test_round_trip();
    test_format_rejects();
    test_longest_line_fits();
    test_parse_bad_lines();
    test_parse_by_hand();
    test_type_name();
    return CHECK_SUMMARY();
}
