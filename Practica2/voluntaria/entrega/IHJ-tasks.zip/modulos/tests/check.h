/*
 * check.h - minimal test runner, no libraries needed. ANSI C89.
 *
 *   CHECK(cond)            fails if cond is false
 *   CHECK_INT(a, b)        fails if a != b, printing both values
 *   CHECK_STR(a, b)        fails if the strings differ, printing both
 *   CHECK_SUMMARY()        prints the totals; use as "return CHECK_SUMMARY();"
 *
 * A failed check prints file:line and goes on, so one run shows every failure.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef CHECK_H
#define CHECK_H

#include <stdio.h>
#include <string.h>

static int check_run = 0;
static int check_failed = 0;

#define CHECK(cond) \
    do { \
        check_run++; \
        if (!(cond)) { \
            check_failed++; \
            printf("%s:%d: FAILED: %s\n", __FILE__, __LINE__, #cond); \
        } \
    } while (0)

#define CHECK_INT(a, b) \
    do { \
        long check_a = (long) (a), check_b = (long) (b); \
        check_run++; \
        if (check_a != check_b) { \
            check_failed++; \
            printf("%s:%d: FAILED: %s == %s (%ld != %ld)\n", \
                   __FILE__, __LINE__, #a, #b, check_a, check_b); \
        } \
    } while (0)

#define CHECK_STR(a, b) \
    do { \
        const char *check_a = (a), *check_b = (b); \
        check_run++; \
        if (strcmp(check_a, check_b) != 0) { \
            check_failed++; \
            printf("%s:%d: FAILED: %s == %s (\"%s\" != \"%s\")\n", \
                   __FILE__, __LINE__, #a, #b, check_a, check_b); \
        } \
    } while (0)

#define CHECK_SUMMARY() \
    (printf("%s: %d checks, %d failed\n", __FILE__, check_run, check_failed), \
     check_failed == 0 ? 0 : 1)

#endif
