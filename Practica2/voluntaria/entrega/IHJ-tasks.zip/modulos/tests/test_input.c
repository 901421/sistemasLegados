/*
 * test_input.c - unit tests for src/input.c,
 * feeding text through tmpfile()
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <stdlib.h>
#include "check.h"
#include "../src/input.h"

/* A temporary stream holding content, ready to be read. */
static FILE *feed(const char *content)
{
    FILE *f = tmpfile();

    if (f == NULL) {
        printf("tmpfile failed\n");
        exit(2);
    }
    fputs(content, f);
    rewind(f);
    return f;
}

static void test_trim(void)
{
    char buf[32];

    strcpy(buf, "  Prueba grupo 02 \t");
    CHECK_STR(input_trim(buf), "Prueba grupo 02");
    strcpy(buf, "   ");
    CHECK_STR(input_trim(buf), "");
    strcpy(buf, "");
    CHECK_STR(input_trim(buf), "");
    strcpy(buf, "x");
    CHECK_STR(input_trim(buf), "x");
    strcpy(buf, "Cami\xC3\xB3n \r");
    CHECK_STR(input_trim(buf), "Cami\xC3\xB3n");    /* non-ASCII bytes are not blanks */
}

/* tareas.c kept only "Prueba" and took the next line as a new date. */
static void test_lines_with_spaces(void)
{
    char buf[INPUT_LINE_SIZE];
    FILE *in = feed("Prueba grupo 02\n Ana Lopez \r\n\nlast without newline");

    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);
    CHECK_STR(buf, "Prueba grupo 02");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);
    CHECK_STR(buf, "Ana Lopez");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);     /* empty line */
    CHECK_STR(buf, "");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);
    CHECK_STR(buf, "last without newline");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_EOF);
    CHECK_STR(buf, "");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_EOF);    /* stays at EOF */
    fclose(in);
}

static void test_empty_input(void)
{
    char buf[INPUT_LINE_SIZE];
    FILE *in = feed("");

    strcpy(buf, "old");
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_EOF);
    CHECK_STR(buf, "");
    fclose(in);
}

static void test_too_long(void)
{
    char small[8];      /* up to 6 characters per line */
    FILE *in = feed("123456\n1234567\nnext\n12345678901234567890");

    CHECK_INT(input_read_line(in, small, sizeof small), INPUT_OK);
    CHECK_STR(small, "123456");
    CHECK_INT(input_read_line(in, small, sizeof small), INPUT_TOO_LONG);
    CHECK_STR(small, "1234567");                               /* the start is kept */
    CHECK_INT(input_read_line(in, small, sizeof small), INPUT_OK); /* rest was dropped */
    CHECK_STR(small, "next");
    CHECK_INT(input_read_line(in, small, sizeof small), INPUT_TOO_LONG);  /* no newline at end */
    CHECK_STR(small, "1234567");
    CHECK_INT(input_read_line(in, small, sizeof small), INPUT_EOF);
    CHECK_INT(input_read_line(in, small, 2), INPUT_ERROR);         /* buffer too small */
    fclose(in);
}

static void test_full_size_line(void)
{
    static char content[INPUT_LINE_MAX + 2 + 6];
    char buf[INPUT_LINE_SIZE];
    FILE *in;

    memset(content, 'x', INPUT_LINE_MAX);
    strcpy(content + INPUT_LINE_MAX, "\nok\n");
    in = feed(content);
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);
    CHECK_INT(strlen(buf), INPUT_LINE_MAX);
    CHECK_INT(input_read_line(in, buf, sizeof buf), INPUT_OK);
    CHECK_STR(buf, "ok");
    fclose(in);
}

/* tareas.c looped forever on a letter. */
static void test_parse_option(void)
{
    int option = -1;

    CHECK(input_parse_option("1", 0, 4, &option));
    CHECK_INT(option, 1);
    CHECK(input_parse_option("0", 0, 4, &option));
    CHECK_INT(option, 0);
    CHECK(input_parse_option("4", 0, 4, &option));
    CHECK(input_parse_option("04", 0, 4, &option));
    CHECK_INT(option, 4);

    option = -1;
    CHECK(!input_parse_option("x", 0, 4, &option));
    CHECK(!input_parse_option("", 0, 4, &option));
    CHECK(!input_parse_option("5", 0, 4, &option));     /* out of range */
    CHECK(!input_parse_option("9", 0, 4, &option));
    CHECK(!input_parse_option("1a", 0, 4, &option));
    CHECK(!input_parse_option("a1", 0, 4, &option));
    CHECK(!input_parse_option("-1", 0, 4, &option));
    CHECK(!input_parse_option("+1", 0, 4, &option));
    CHECK(!input_parse_option("1 2", 0, 4, &option));
    CHECK(!input_parse_option("0001", 0, 4, &option));  /* more than 3 digits */
    CHECK(!input_parse_option("99999999999", 0, 4, &option));
    CHECK_INT(option, -1);                              /* untouched on error */

    /* With a wide range a letter could still give an in-range value ("1a" = 59
       if only the range were checked), so these prove digits are required. */
    CHECK(!input_parse_option("1a", 0, 999, &option));
    CHECK(!input_parse_option("x", 0, 999, &option));
    CHECK(!input_parse_option("1:", 0, 999, &option));
    CHECK(!input_parse_option(" 1", 0, 999, &option));
    CHECK(input_parse_option("999", 0, 999, &option));
    CHECK_INT(option, 999);
}

int main(void)
{
    test_trim();
    test_lines_with_spaces();
    test_empty_input();
    test_too_long();
    test_full_size_line();
    test_parse_option();
    return CHECK_SUMMARY();
}
