/*
 * input.c - see input.h.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <ctype.h>
#include <string.h>
#include "input.h"

PUBLIC char *input_trim(char *text)
{
    size_t start = 0;
    size_t end = strlen(text);

    while (end > 0 && isspace((unsigned char) text[end - 1])) {
        end--;
    }
    while (start < end && isspace((unsigned char) text[start])) {
        start++;
    }
    memmove(text, text + start, end - start);
    text[end - start] = '\0';
    return text;
}

PUBLIC InputStatus input_read_line(FILE *in, char *buf, size_t size)
{
    size_t len;

    if (size < 3) {
        return INPUT_ERROR;
    }
    if (fgets(buf, (int) size, in) == NULL) {
        buf[0] = '\0';
        return ferror(in) ? INPUT_ERROR : INPUT_EOF;
    }
    len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[--len] = '\0';
    } else if (!feof(in)) {
        /* Buffer full before the line end: keep the start (a text is
           then cut to its limit) and drop the rest, so it does not
           become the answer to the next question. */
        int c;

        do {
            c = getc(in);
        } while (c != '\n' && c != EOF);
        input_trim(buf);
        return INPUT_TOO_LONG;
    }
    input_trim(buf);    /* also removes the '\r' of "\r\n" */
    return INPUT_OK;
}

PUBLIC int input_parse_option(const char *text, int min, int max,
                              int *option)
{
    int value = 0;
    int digits = 0;

    for (; *text != '\0'; text++) {
        if (*text < '0' || *text > '9' || ++digits > 3) {
            return 0;
        }
        value = value * 10 + (*text - '0');
    }
    if (digits == 0 || value < min || value > max) {
        return 0;
    }
    *option = value;
    return 1;
}
