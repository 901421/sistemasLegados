/*
 * task.c - see task.h.
 *
 * In tareas.c each task was a 32-byte line (lines 7 and 9) filled with
 * strcat without checking the length, so a longer text ran into the
 * next task. Here every text has a limit and is checked against it.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#include "task.h"

#define ID_DIGITS 4

PUBLIC const char *task_type_name(TaskType type)
{
    return type == TASK_SPECIFIC ? "SPECIFIC" : "GENERAL";
}

PUBLIC size_t task_text_length(const char *text)
{
    size_t count = 0;

    for (; *text != '\0'; text++) {
#if TASK_UTF8
        /* UTF-8 continuation bytes (10xxxxxx) start no character */
        if (((unsigned char) *text & 0xC0) == 0x80) {
            continue;
        }
#endif
        count++;
    }
    return count;
}

PUBLIC TextStatus task_check_text(const char *text, size_t max_chars)
{
    const char *p;
    int only_blanks = 1;

    for (p = text; *p != '\0'; p++) {
        if (iscntrl((unsigned char) *p)) {
            return TEXT_BAD_CHAR;
        }
        if (!isspace((unsigned char) *p)) {
            only_blanks = 0;
        }
    }
    if (only_blanks) {
        return TEXT_EMPTY;
    }
    /* Characters, and also bytes: badly formed UTF-8 (a lead byte
       followed by many continuation bytes) would count as few
       characters but not fit. */
    if (task_text_length(text) > max_chars
        || (size_t) (p - text) > max_chars * 4) {
        return TEXT_TOO_LONG;
    }
    return TEXT_OK;
}

PUBLIC LineStatus task_validate(const Task *task)
{
    if (task->id < 0 || task->id > TASK_ID_MAX) {
        return LINE_BAD_ID;
    }
    if (task->type != TASK_GENERAL && task->type != TASK_SPECIFIC) {
        return LINE_BAD_TYPE;
    }
    if (!date_is_valid(&task->date)) {
        return LINE_BAD_DATE;
    }
    if (task->type == TASK_GENERAL
        ? task->name[0] != '\0'
        : task_check_text(task->name, TASK_NAME_MAX) != TEXT_OK) {
        return LINE_BAD_NAME;
    }
    if (task_check_text(task->description, TASK_DESC_MAX) != TEXT_OK) {
        return LINE_BAD_DESCRIPTION;
    }
    return LINE_OK;
}

/* Byte length of the first n characters of text, or of the whole of
   it if it has fewer. */
static size_t bytes_of_chars(const char *text, size_t n)
{
    const char *p = text;

    while (*p != '\0') {
#if TASK_UTF8
        if (((unsigned char) *p & 0xC0) != 0x80) {
            if (n == 0) {
                break;
            }
            n--;
        }
#else
        if (n == 0) {
            break;
        }
        n--;
#endif
        p++;
    }
    return (size_t) (p - text);
}

PUBLIC int task_truncate_text(char *text, size_t max_chars)
{
    size_t n = bytes_of_chars(text, max_chars);

#if TASK_UTF8
    /* Bad UTF-8 can make few characters of many bytes: also cut by
       bytes, at the start of a character. */
    if (n > max_chars * 4) {
        n = max_chars * 4;
        while (n > 0 && ((unsigned char) text[n] & 0xC0) == 0x80) {
            n--;
        }
    }
#endif
    if (text[n] == '\0') {
        return 0;
    }
    while (n > 0 && text[n - 1] == ' ') {
        n--;
    }
    text[n] = '\0';
    return 1;
}

/* Appends text and then blanks up to width characters. Returns 0 if
   it does not fit in size bytes. */
static int append_padded(char *buf, size_t size, size_t *len,
                         const char *text, size_t width)
{
    size_t bytes = strlen(text);
    size_t chars = task_text_length(text);

    if (chars > width
        || *len + bytes + (width - chars) + 1 > size) {
        return 0;
    }
    memcpy(buf + *len, text, bytes);
    *len += bytes;
    for (; chars < width; chars++) {
        buf[(*len)++] = ' ';
    }
    buf[*len] = '\0';
    return 1;
}

PUBLIC int task_format_line(const Task *task, char *buf, size_t size)
{
    /* "nnnn T YYYY-MM-DD " */
    char head[TASK_COL_NAME + 1];
    char iso[DATE_TEXT_SIZE];
    size_t len;

    if (size == 0 || task_validate(task) != LINE_OK) {
        return 0;
    }
    sprintf(head, "%04ld %c %s ", task->id,
            task->type == TASK_SPECIFIC ? 'S' : 'G',
            date_to_iso(&task->date, iso));
    len = strlen(head);
    if (len + 1 > size) {
        return 0;
    }
    strcpy(buf, head);
    /* the name, the blank column 39 and the description */
    return append_padded(buf, size, &len, task->name, TASK_NAME_MAX)
        && append_padded(buf, size, &len, "", 1)
        && append_padded(buf, size, &len, task->description,
                         task_text_length(task->description));
}

/* Copies the text of a field (n bytes at from) into dest without the
   blanks after it. Returns 0 if it does not fit. */
static int copy_field(char *dest, size_t dest_size, const char *from,
                      size_t n)
{
    while (n > 0 && from[n - 1] == ' ') {
        n--;
    }
    if (n + 1 > dest_size) {
        return 0;
    }
    memcpy(dest, from, n);
    dest[n] = '\0';
    return 1;
}

PUBLIC LineStatus task_parse_line(const char *line, Task *out)
{
    char date_text[DATE_TEXT_SIZE];
    const char *p;
    Task task;
    LineStatus status;
    size_t n;
    int i;

    if (line == NULL) {
        return LINE_BAD_FIELDS;
    }
    /* Up to the name the columns are plain ASCII: one byte each. */
    if (strlen(line) < TASK_COL_NAME) {
        return LINE_BAD_FIELDS;
    }
    if (line[ID_DIGITS] != ' ' || line[TASK_COL_TYPE + 1] != ' '
        || line[TASK_COL_NAME - 1] != ' ') {
        return LINE_BAD_FIELDS;
    }
    task.id = 0;
    for (i = 0; i < ID_DIGITS; i++) {
        if (line[i] < '0' || line[i] > '9') {
            return LINE_BAD_ID;
        }
        task.id = task.id * 10 + (line[i] - '0');
    }
    if (line[TASK_COL_TYPE] == 'G') {
        task.type = TASK_GENERAL;
    } else if (line[TASK_COL_TYPE] == 'S') {
        task.type = TASK_SPECIFIC;
    } else {
        return LINE_BAD_TYPE;
    }
    memcpy(date_text, line + TASK_COL_DATE, DATE_TEXT_SIZE - 1);
    date_text[DATE_TEXT_SIZE - 1] = '\0';
    if (date_from_iso(date_text, &task.date) != DATE_OK) {
        return LINE_BAD_DATE;
    }

    /* Name: the next TASK_NAME_MAX characters (fewer if the record
       ends), and it cannot start with a blank: that would be a field
       out of its columns. */
    p = line + TASK_COL_NAME;
    n = bytes_of_chars(p, TASK_NAME_MAX);
    if (*p == ' ' && task.type == TASK_SPECIFIC) {
        return LINE_BAD_NAME;
    }
    if (!copy_field(task.name, sizeof task.name, p, n)) {
        return LINE_BAD_NAME;
    }
    p += n;
    /* Then the blank column, and the description up to the end. */
    if (*p != '\0') {
        if (*p != ' ') {
            return LINE_BAD_FIELDS;
        }
        p++;
    }
    if (*p == ' ') {
        return LINE_BAD_DESCRIPTION;
    }
    if (!copy_field(task.description, sizeof task.description, p,
                    strlen(p))) {
        return LINE_BAD_DESCRIPTION;
    }
    status = task_validate(&task);
    if (status != LINE_OK) {
        return status;
    }
    *out = task;
    return LINE_OK;
}
