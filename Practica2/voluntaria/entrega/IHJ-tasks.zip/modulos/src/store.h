/*
 * store.h - the task list in memory and in tasks.dat.
 *
 * tareas.c kept its tasks only in memory, so they were lost when it
 * ended. Here the list is read at start and written back after every
 * change. ANSI C89 (stdio only).
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef STORE_H
#define STORE_H

#include "public.h"

#include <stddef.h>
#include "task.h"

/* How many skipped lines the load report lists one by one. */
#define STORE_REPORT_MAX 10

typedef enum {
    STORE_OK = 0,
    STORE_ERR_OPEN,         /* file exists but cannot be opened */
    STORE_ERR_READ,
    STORE_ERR_WRITE,
    STORE_ERR_MEMORY,
    /* bad lines found and the backup copy failed */
    STORE_ERR_BACKUP,
    /* save refused: the backup failed at load */
    STORE_ERR_READ_ONLY,
    /* no task number left (TASK_ID_MAX reached) */
    STORE_ERR_FULL,
    /* the task to add does not pass task_validate */
    STORE_ERR_INVALID,
    /* no task with that number */
    STORE_ERR_NOT_FOUND
} StoreStatus;

typedef enum {
    SKIP_BAD_FIELDS,
    SKIP_BAD_ID,
    SKIP_BAD_TYPE,
    SKIP_BAD_DATE,
    SKIP_BAD_NAME,
    SKIP_BAD_DESCRIPTION,
    SKIP_DUPLICATE_ID,
    SKIP_TOO_LONG,
    SKIP_BAD_CONTROL        /* a line starting with '*' but bad */
} SkipReason;

typedef struct {
    long line;              /* 1-based line number in the file */
    SkipReason reason;
} SkippedLine;

typedef struct {
    long skipped;                           /* total lines skipped */
    /* entries used in lines[] */
    int listed;
    SkippedLine lines[STORE_REPORT_MAX];
    /* 1 if the file was copied to the backup */
    int backup_made;
} LoadReport;

typedef struct {
    Task *items;
    size_t count;
    size_t capacity;
    /* number for the next task added; it never goes back */
    long next_id;
    /* set when the backup of a damaged file failed */
    int read_only;
} TaskList;

PUBLIC void task_list_init(TaskList *list);
PUBLIC void task_list_free(TaskList *list);

/*
 * Gives task the next number and appends a copy to the list. On
 * STORE_OK, task->id holds that number; on error nothing changes.
 */
PUBLIC StoreStatus task_list_add(TaskList *list, Task *task);

/*
 * Loads path into list (which must be empty).
 * - A missing file is not an error: the list stays empty.
 * - Bad lines are skipped and reported. If there is any, the whole
 *   file is first copied to backup_path so nothing is lost when the
 *   list is saved.
 * - Empty lines are ignored, and "\r\n" line ends are accepted.
 * - The control record "*NEXT nnnn" gives the next number; without
 *   it, or if a task has a higher one, it is the highest number + 1.
 * On an error other than STORE_ERR_BACKUP the list is left empty.
 */
PUBLIC StoreStatus store_load(const char *path, const char *backup_path,
                       TaskList *list, LoadReport *report);

/*
 * Writes the control record and the whole list to path through
 * "path.tmp" and rename, so a crash while writing never leaves a
 * half-written tasks.dat.
 */
PUBLIC StoreStatus store_save(const char *path, const TaskList *list);

/* task_list_add, then store_save; a failed save undoes the add. */
PUBLIC StoreStatus store_add_and_save(const char *path, TaskList *list,
                                      Task *task);

/* The task with number id, or NULL. */
PUBLIC const Task *task_list_find(const TaskList *list, long id);

/*
 * Takes the task with number id out of the list, keeping the order of
 * the rest, and writes the whole file again through store_save. A
 * failed save puts the task back where it was. next_id does not
 * change, so the number is never given again.
 */
PUBLIC StoreStatus store_delete_and_save(const char *path,
                                         TaskList *list, long id);

/* Short upper-case messages for the screen. */
PUBLIC const char *store_status_text(StoreStatus status);
PUBLIC const char *store_skip_text(SkipReason reason);

#endif
