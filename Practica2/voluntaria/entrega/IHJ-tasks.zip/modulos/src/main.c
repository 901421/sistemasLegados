/*
 * main.c - command line of the task manager (rewrite of tareas.c).
 *
 *   tasks [--plain] [--file PATH] [--today DD/MM/YYYY]
 *
 *   --plain   no colours or clear-screen, answers echoed (tests)
 *   --file    task file, tasks.dat by default; the backup of x.dat
 *             is x.bak
 *   --today   fixed date for "today", so tests always give the same
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app.h"
#include "date.h"

/* Colours by default; the MUSIC/SP single file sets it to 0. */
#ifndef TASKS_DEFAULT_ANSI
#define TASKS_DEFAULT_ANSI 1
#endif

#define DEFAULT_FILE "tasks.dat"
#define BACKUP_SUFFIX ".bak"

/* tasks.dat -> tasks.bak; a name not ending in .dat gets .bak added.
   Caller frees. */
static char *backup_path(const char *path)
{
    size_t len = strlen(path);
    char *backup = (char *) malloc(len + sizeof BACKUP_SUFFIX);

    if (backup == NULL) {
        return NULL;
    }
    strcpy(backup, path);
    if (len > 4 && strcmp(path + len - 4, ".dat") == 0) {
        backup[len - 4] = '\0';
    }
    strcat(backup, BACKUP_SUFFIX);
    return backup;
}

static int usage(void)
{
    fprintf(stderr, "usage: tasks [--plain] [--file PATH]"
                    " [--today DD/MM/YYYY]\n");
    return 2;
}

int main(int argc, char **argv)
{
    const char *path = DEFAULT_FILE;
    const char *today_text = NULL;
    char *backup;
    int ansi = TASKS_DEFAULT_ANSI;
    int echo = 0;
    int i, code;
    Date today;

    for (i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--plain") == 0) {
            ansi = 0;
            echo = 1;
        } else if (strcmp(argv[i], "--file") == 0 && i + 1 < argc
                   && argv[i + 1][0] != '\0') {
            path = argv[++i];
        } else if (strcmp(argv[i], "--today") == 0 && i + 1 < argc) {
            today_text = argv[++i];
        } else {
            return usage();
        }
    }

    if (!date_today(&today)) {
        fprintf(stderr, "tasks: the system clock is not available\n");
        return 1;
    }
    if (today_text != NULL
        && date_parse(today_text, today.year, &today) != DATE_OK) {
        fprintf(stderr,
                "tasks: --today needs a valid date, DD/MM/YYYY\n");
        return 2;
    }

    backup = backup_path(path);
    if (backup == NULL) {
        fprintf(stderr, "tasks: out of memory\n");
        return 1;
    }

    code = app_run(stdin, stdout, ansi, echo, path, backup, &today);
    free(backup);
    return code;
}
