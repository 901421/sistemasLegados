/*
 * app.h - the task manager: a single menu over the task list.
 *
 * Replaces the three menus of the original (MENU PRINCIPAL, ASSIGN
 * TASKS, VIEW TASKS) with one. Everything it needs comes in as
 * parameters, so a whole session can be run from a file in the tests.
 * ANSI C89.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef APP_H
#define APP_H

#include "public.h"

#include <stdio.h>
#include "date.h"

/* Tasks per page in the listings. */
#define APP_PAGE_SIZE 15

/*
 * Runs the program until EXIT or end of input.
 *   in, out      where to read answers and write screens
 *   ansi         1 for colours and clear-screen, 0 for plain text
 *   echo         1 to write back each answer (input from a file)
 *   path, backup the task file and where to copy it if it is damaged
 *   today        sets the default year and the past-date warning
 * Returns the process exit code: 0 normally, 1 if the task file cannot
 * be used.
 */
PUBLIC int app_run(FILE *in, FILE *out, int ansi, int echo,
            const char *path, const char *backup, const Date *today);

#endif
