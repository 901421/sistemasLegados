/*
 * date.c - see date.h.
 *
 * tareas.c copied the date into the task as typed (lines 37 and 73), so
 * "3213", "12345" and "ab12" were all stored. Here a date is checked
 * before it reaches a task.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <stdio.h>
#include <time.h>
#include "date.h"

PUBLIC int date_is_leap(int year)
{
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

PUBLIC int date_days_in_month(int year, int month)
{
    static const int days[12] = { 31, 28, 31, 30, 31, 30, 31, 31, 30,
                                 31, 30, 31 };

    if (month < 1 || month > 12) {
        return 0;
    }
    if (month == 2 && date_is_leap(year)) {
        return 29;
    }
    return days[month - 1];
}

PUBLIC int date_is_valid(const Date *d)
{
    return d->year >= DATE_MIN_YEAR && d->year <= DATE_MAX_YEAR
        && d->day >= 1
        && d->day <= date_days_in_month(d->year, d->month);
}

/*
 * Reads between min_digits and max_digits decimal digits from *p into
 * *value and advances *p. Returns 0 if the count of digits is outside
 * that range. Hand-made instead of strtol so signs, spaces and overflow
 * cannot slip in.
 */
static int read_number(const char **p, int min_digits, int max_digits,
                       int *value)
{
    int count = 0;
    int result = 0;

    while (**p >= '0' && **p <= '9') {
        if (count == max_digits) {
            return 0;
        }
        result = result * 10 + (**p - '0');
        (*p)++;
        count++;
    }
    if (count < min_digits) {
        return 0;
    }
    *value = result;
    return 1;
}

/* Builds the date; *out is written only if the date exists. */
static DateStatus finish(int year, int month, int day, Date *out)
{
    Date d;

    d.year = year;
    d.month = month;
    d.day = day;
    if (!date_is_valid(&d)) {
        return DATE_ERR_INVALID;
    }
    *out = d;
    return DATE_OK;
}

PUBLIC DateStatus date_parse(const char *text, int default_year,
                             Date *out)
{
    const char *p = text;
    int ddmm, day, month, year;

    if (text == NULL) {
        return DATE_ERR_FORMAT;
    }

    /* DDMM: exactly four digits and nothing else. */
    if (read_number(&p, 4, 4, &ddmm) && *p == '\0') {
        return finish(default_year, ddmm % 100, ddmm / 100, out);
    }

    /* D/M, DD/MM, D/M/YYYY, DD/MM/YYYY */
    p = text;
    if (!read_number(&p, 1, 2, &day) || *p != '/') {
        return DATE_ERR_FORMAT;
    }
    p++;
    if (!read_number(&p, 1, 2, &month)) {
        return DATE_ERR_FORMAT;
    }
    if (*p == '\0') {
        return finish(default_year, month, day, out);
    }
    if (*p != '/') {
        return DATE_ERR_FORMAT;
    }
    p++;
    if (!read_number(&p, 4, 4, &year) || *p != '\0') {
        return DATE_ERR_FORMAT;
    }
    return finish(year, month, day, out);
}

PUBLIC DateStatus date_from_iso(const char *text, Date *out)
{
    const char *p = text;
    int year, month, day;

    if (text == NULL
        || !read_number(&p, 4, 4, &year) || *p++ != '-'
        || !read_number(&p, 2, 2, &month) || *p++ != '-'
        || !read_number(&p, 2, 2, &day) || *p != '\0') {
        return DATE_ERR_FORMAT;
    }
    return finish(year, month, day, out);
}

/* Fields are checked by date_is_valid, so sprintf cannot overflow. */
PUBLIC char *date_to_iso(const Date *d, char *buf)
{
    sprintf(buf, "%04d-%02d-%02d", d->year, d->month, d->day);
    return buf;
}

PUBLIC char *date_to_display(const Date *d, char *buf)
{
    sprintf(buf, "%02d/%02d/%04d", d->day, d->month, d->year);
    return buf;
}

PUBLIC int date_compare(const Date *a, const Date *b)
{
    if (a->year != b->year) {
        return a->year - b->year;
    }
    if (a->month != b->month) {
        return a->month - b->month;
    }
    return a->day - b->day;
}

PUBLIC int date_today(Date *out)
{
    time_t now = time(NULL);
    struct tm *local;

    if (now == (time_t) -1) {
        return 0;
    }
    local = localtime(&now);
    if (local == NULL) {
        return 0;
    }
    out->year = local->tm_year + 1900;
    out->month = local->tm_mon + 1;
    out->day = local->tm_mday;
    return 1;
}
