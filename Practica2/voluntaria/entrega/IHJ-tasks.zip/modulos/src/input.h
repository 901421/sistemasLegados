/*
 * input.h - reading what the user types, one whole line at a time.
 *
 * tareas.c read with scanf. "%s" kept the first word and left the rest
 * for the next question, and "%d" never consumed a letter, so the menu
 * looped forever. Reading whole lines removes both problems. ANSI C89.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef INPUT_H
#define INPUT_H

#include "public.h"

#include <stdio.h>
#include <stddef.h>

/* Longest line accepted, in bytes; texts get their own limits later. */
#define INPUT_LINE_MAX  510
#define INPUT_LINE_SIZE (INPUT_LINE_MAX + 2)    /* + '\n' + '\0' */

typedef enum {
    INPUT_OK = 0,
    /* end of input (Ctrl-D, closed pipe) and nothing read */
    INPUT_EOF,
    /* longer than the buffer: buf keeps the start, trimmed, and the
       rest of the line is dropped */
    INPUT_TOO_LONG,
    INPUT_ERROR         /* read error */
} InputStatus;

/* Removes leading and trailing blanks in place. Returns text. */
PUBLIC char *input_trim(char *text);

/*
 * Reads one line from in into buf (size bytes, at least 3), without the
 * line end ("\n" or "\r\n") and trimmed. A last line with no '\n'
 * counts. On INPUT_EOF and INPUT_ERROR, buf is left empty.
 */
PUBLIC InputStatus input_read_line(FILE *in, char *buf, size_t size);

/*
 * Menu option: only digits (no sign, no spaces, at most 3) and within
 * [min, max]. Returns 1 and sets *option, or 0 if text is not valid.
 */
PUBLIC int input_parse_option(const char *text, int min, int max,
                              int *option);

#endif
