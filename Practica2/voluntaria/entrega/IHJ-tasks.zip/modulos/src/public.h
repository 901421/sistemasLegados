/*
 * public.h - how the functions of a module are declared.
 *
 * Built from the modules, PUBLIC is empty and the functions are normal
 * external functions. In the single-file build (tools/single_file.sh)
 * it is "static": every function stays inside the one file, so the old
 * linkers of MUSIC/SP never see their names. ANSI C89 only promises 6
 * significant characters for external names, and task_list_add,
 * task_list_free and task_list_init would look the same.
 *
 * PUBLIC goes on the prototype and on the definition. gcc lets the
 * definition inherit "static" from the prototype, but Waterloo C 3.2
 * stops with "Linkage of '...' conflicts with previous reference".
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef PUBLIC_H
#define PUBLIC_H

#ifndef PUBLIC
#define PUBLIC
#endif

#endif
