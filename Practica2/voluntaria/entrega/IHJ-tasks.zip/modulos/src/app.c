/*
 * app.c - see app.h.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "app.h"
#include "input.h"
#include "screen.h"
#include "store.h"
#include "task.h"

/* What a step of a form ended with. */
typedef enum {
    STEP_OK,
    STEP_CANCEL,        /* empty answer: back to the menu */
    /* end of input or read error: leave the program */
    STEP_END
} Step;

typedef struct {
    FILE *in;
    Screen screen;
    const char *path;
    Date today;
    TaskList list;
    MsgKind msg_kind;           /* status line for the next menu */
    char msg[SCREEN_WIDTH];
} App;

static void set_message(App *app, MsgKind kind, const char *text)
{
    app->msg_kind = kind;
    strncpy(app->msg, text, sizeof app->msg - 1);
    app->msg[sizeof app->msg - 1] = '\0';
}

/* Reads an answer and echoes it in plain mode. */
static InputStatus read_answer(App *app, char *buf, size_t size)
{
    InputStatus status;

    screen_flush(&app->screen);
    status = input_read_line(app->in, buf, size);

    screen_echo(&app->screen, buf);     /* "" on end or error */
    return status;
}

/* ---- Start: load the file ---------------------------------------- */

/* Returns 0 if the program cannot go on. */
static int load(App *app, const char *backup)
{
    LoadReport report;
    StoreStatus status = store_load(app->path, backup, &app->list,
                                    &report);
    char text[SCREEN_WIDTH];
    char answer[INPUT_LINE_SIZE];
    int i;

    if (status != STORE_OK && status != STORE_ERR_BACKUP) {
        screen_message(&app->screen, MSG_ERROR,
                       store_status_text(status));
        screen_line(&app->screen, app->path);
        return 0;
    }
    if (report.skipped == 0) {
        return 1;
    }

    /* Some lines were damaged: say which before anything else. */
    screen_clear(&app->screen);
    screen_title(&app->screen, "TASK FILE CHECK");
    screen_newline(&app->screen);
    sprintf(text, "%ld LINE(S) OF THE TASK FILE SKIPPED",
            report.skipped);
    screen_message(&app->screen, MSG_WARNING, text);
    for (i = 0; i < report.listed; i++) {
        sprintf(text, "LINE %ld: %s", report.lines[i].line,
                store_skip_text(report.lines[i].reason));
        screen_line(&app->screen, text);
    }
    if (report.skipped > report.listed) {
        sprintf(text, "... AND %ld MORE",
                report.skipped - report.listed);
        screen_line(&app->screen, text);
    }
    screen_newline(&app->screen);
    if (status == STORE_ERR_BACKUP) {
        screen_message(&app->screen, MSG_ERROR,
                       store_status_text(status));
        set_message(app, MSG_ERROR,
                    store_status_text(STORE_ERR_READ_ONLY));
    } else {
        screen_line(&app->screen, "THE WHOLE FILE WAS COPIED TO:");
        screen_line(&app->screen, backup);
    }
    screen_newline(&app->screen);
    screen_prompt_centered(&app->screen, "PRESS ENTER TO CONTINUE");
    /* at end of input the menu will leave */
    read_answer(app, answer, sizeof answer);
    return 1;
}

/* ---- Forms ------------------------------------------------------- */

#define FORM_FIELDS 3   /* date, name, description */

/*
 * A task being typed in. In ANSI mode the whole form is drawn again
 * before every question, with the answers already given in place and
 * the last message in a fixed line, so the screen never scrolls. In
 * plain mode only the message and the question are written, one after
 * the other.
 */
typedef struct {
    const char *title;
    const char *help[6];         /* date, name, desc, cut, "", cancel */
    size_t help_lines;
    const char *labels[FORM_FIELDS];
    /* answers given, as shown */
    char values[FORM_FIELDS][TASK_DESC_SIZE];
    /* how many labels[] are answered */
    size_t done;
    MsgKind msg_kind;
    char msg[SCREEN_WIDTH];
} Form;

/* Longest label, so the answers line up in ANSI mode. */
#define FORM_LABEL_WIDTH 19     /* strlen("DATE (DD/MM/YYYY): ") */

static void form_message(Form *form, MsgKind kind, const char *text)
{
    form->msg_kind = kind;
    strncpy(form->msg, text, sizeof form->msg - 1);
    form->msg[sizeof form->msg - 1] = '\0';
}

/* Draws what is needed before asking labels[form->done]. */
static void form_prompt(App *app, Form *form)
{
    Screen *s = &app->screen;
    size_t i;

    if (s->ansi) {
        screen_clear(s);
        screen_box(s, form->title, NULL, form->help, form->help_lines);
        screen_newline(s);
        screen_message(s, form->msg_kind, form->msg);
        screen_newline(s);
        for (i = 0; i < form->done; i++) {
            screen_field(s, form->labels[i], FORM_LABEL_WIDTH,
                         form->values[i]);
        }
        screen_field(s, form->labels[form->done], FORM_LABEL_WIDTH,
                     NULL);
    } else {
        if (form->msg_kind != MSG_NONE) {
            screen_message(s, form->msg_kind, form->msg);
        }
        screen_prompt(s, form->labels[form->done]);
    }
    form_message(form, MSG_NONE, "");
}

/* Stores the answer as shown and moves on to the next label. */
static void form_answered(Form *form, const char *shown)
{
    strcpy(form->values[form->done], shown);
    form->done++;
}

static Step ask_date(App *app, Form *form, Date *date)
{
    char answer[INPUT_LINE_SIZE];
    char shown[DATE_TEXT_SIZE];

    for (;;) {
        InputStatus status;

        form_prompt(app, form);
        status = read_answer(app, answer, sizeof answer);
        if (status == INPUT_EOF || status == INPUT_ERROR) {
            return STEP_END;
        }
        if (status == INPUT_OK && answer[0] == '\0') {
            return STEP_CANCEL;
        }
        switch (status == INPUT_OK
                ? date_parse(answer, app->today.year, date)
                : DATE_ERR_FORMAT) {
        case DATE_OK:
            if (date_compare(date, &app->today) < 0) {
                form_message(form, MSG_WARNING,
                             "WARNING: THAT DATE IS IN THE PAST");
            }
            form_answered(form, date_to_display(date, shown));
            return STEP_OK;
        case DATE_ERR_FORMAT:
            form_message(form, MSG_ERROR,
                         "WRONG FORMAT: USE DD/MM/YYYY, DD/MM OR DDMM");
            break;
        case DATE_ERR_INVALID:
            form_message(form, MSG_ERROR, "THAT DATE DOES NOT EXIST");
            break;
        }
    }
}

/* Name or description: dest is TASK_NAME_SIZE or TASK_DESC_SIZE. A
   longer answer is cut to max_chars, with a warning that says so, and
   *cut is set to 1. */
static Step ask_text(App *app, Form *form, const char *field,
                     size_t max_chars, char *dest, int *cut)
{
    char answer[INPUT_LINE_SIZE];
    char warning[SCREEN_WIDTH];

    for (;;) {
        InputStatus status;
        TextStatus check;

        form_prompt(app, form);
        status = read_answer(app, answer, sizeof answer);
        if (status == INPUT_EOF || status == INPUT_ERROR) {
            return STEP_END;
        }
        if (status == INPUT_OK && answer[0] == '\0') {
            return STEP_CANCEL;
        }
        *cut = task_truncate_text(answer, max_chars);
        if (*cut) {
            sprintf(warning, "%s CUT TO %lu CHARACTERS", field,
                    (unsigned long) max_chars);
            form_message(form, MSG_WARNING, warning);
        }
        check = task_check_text(answer, max_chars);
        if (check == TEXT_OK) {
            /* fits: max_chars characters of at most 4 bytes */
            strcpy(dest, answer);
            form_answered(form, answer);
            return STEP_OK;
        }
        form_message(form, MSG_ERROR,
                     "TABS AND CONTROL CHARACTERS ARE NOT ALLOWED");
    }
}

/* Options 1 and 2. Returns 0 if the program must end. */
static int assign(App *app, TaskType type)
{
    char date_help[SCREEN_WIDTH], name_help[SCREEN_WIDTH],
        desc_help[SCREEN_WIDTH];
    Form form;
    size_t fields = 0;
    Task task;
    Step step;
    StoreStatus status;
    char text[SCREEN_WIDTH];
    int name_cut = 0, desc_cut = 0;

    if (app->list.read_only) {
        set_message(app, MSG_ERROR,
                    store_status_text(STORE_ERR_READ_ONLY));
        return 1;
    }
    /* Help made from the limits, so it always matches them. */
    strcpy(date_help, "DATE: DD/MM/YYYY, DD/MM OR DDMM");
    sprintf(name_help, "NAME: UP TO %d CHARACTERS", TASK_NAME_MAX);
    sprintf(desc_help, "DESCRIPTION: UP TO %d CHARACTERS",
            TASK_DESC_MAX);

    form.title = type == TASK_GENERAL ? "ASSIGN GENERAL TASK"
        : "ASSIGN SPECIFIC TASK";
    form.help_lines = 0;
    form.help[form.help_lines++] = date_help;
    form.labels[fields++] = "DATE (DD/MM/YYYY): ";
    if (type == TASK_SPECIFIC) {
        form.help[form.help_lines++] = name_help;
        form.labels[fields++] = "NAME: ";
    }
    form.help[form.help_lines++] = desc_help;
    form.labels[fields++] = "DESCRIPTION: ";
    form.help[form.help_lines++] = "LONGER ANSWERS ARE CUT";
    form.help[form.help_lines++] = "";
    form.help[form.help_lines++] = "EMPTY ANSWER = CANCEL";
    form.done = 0;
    form_message(&form, MSG_NONE, "");

    /* Plain mode draws the help once, ANSI mode at every question. */
    if (!app->screen.ansi) {
        screen_clear(&app->screen);
        screen_box(&app->screen, form.title, NULL, form.help,
                   form.help_lines);
        screen_newline(&app->screen);
    }

    task.type = type;
    task.name[0] = '\0';
    step = ask_date(app, &form, &task.date);
    if (step == STEP_OK && type == TASK_SPECIFIC) {
        step = ask_text(app, &form, "NAME", TASK_NAME_MAX,
                        task.name, &name_cut);
    }
    if (step == STEP_OK) {
        step = ask_text(app, &form, "DESCRIPTION", TASK_DESC_MAX,
                        task.description, &desc_cut);
    }
    if (step == STEP_END) {
        return 0;
    }
    if (step == STEP_CANCEL) {
        set_message(app, MSG_WARNING, "CANCELLED: NOTHING WAS SAVED");
        return 1;
    }

    status = store_add_and_save(app->path, &app->list, &task);
    if (status == STORE_OK) {
        sprintf(text, "%s TASK %ld ASSIGNED", task_type_name(type),
                task.id);
        /* The form is gone: say here what was cut. */
        if (name_cut && desc_cut) {
            strcat(text, ", NAME AND DESCRIPTION CUT");
        } else if (name_cut) {
            sprintf(text + strlen(text), ", NAME CUT TO %d",
                    TASK_NAME_MAX);
        } else if (desc_cut) {
            sprintf(text + strlen(text), ", DESCRIPTION CUT TO %d",
                    TASK_DESC_MAX);
        }
        set_message(app, name_cut || desc_cut ? MSG_WARNING : MSG_INFO,
                    text);
    } else {
        set_message(app, MSG_ERROR, store_status_text(status));
    }
    return 1;
}

/* ---- Listings ---------------------------------------------------- */

/* By task number, whatever the order in the file and the dates. */
static int by_number(const void *a, const void *b)
{
    const Task *ta = *(const Task *const *) a;
    const Task *tb = *(const Task *const *) b;

    return ta->id < tb->id ? -1 : ta->id > tb->id;
}

/* A task number typed in a listing: 1 to 4 digits. */
static int parse_task_number(const char *text, long *id)
{
    long value = 0;
    int digits = 0;

    for (; *text != '\0'; text++) {
        if (*text < '0' || *text > '9' || ++digits > 4) {
            return 0;
        }
        value = value * 10 + (*text - '0');
    }
    if (digits == 0) {
        return 0;
    }
    *id = value;
    return 1;
}

/* Shows the task and asks Y or N, until one of them is typed.
   Returns 1 for Y, 0 for N, -1 if the program must end. */
static int confirm_delete(App *app, const Task *task)
{
    const Task *row[1];
    char question[SCREEN_WIDTH];
    char answer[INPUT_LINE_SIZE];
    MsgKind kind = MSG_NONE;
    const char *msg = "";

    row[0] = task;
    sprintf(question, "DELETE TASK %ld? (Y/N): ", task->id);
    for (;;) {
        InputStatus status;

        screen_clear(&app->screen);
        screen_title(&app->screen, "DELETE TASK");
        screen_newline(&app->screen);
        screen_task_table(&app->screen, task->type, row, 1);
        screen_newline(&app->screen);
        screen_message(&app->screen, kind, msg);
        screen_prompt_centered(&app->screen, question);
        status = read_answer(app, answer, sizeof answer);
        if (status == INPUT_EOF || status == INPUT_ERROR) {
            return -1;
        }
        if (status == INPUT_OK && answer[1] == '\0') {
            if (answer[0] == 'Y' || answer[0] == 'y') {
                return 1;
            }
            if (answer[0] == 'N' || answer[0] == 'n') {
                return 0;
            }
        }
        kind = MSG_ERROR;
        msg = "ANSWER Y OR N";
    }
}

#define PROMPT_ONE_PAGE \
    "TASK NUMBER TO DELETE, OR ENTER TO RETURN TO THE MENU: "
#define PROMPT_PAGES \
    "TASK NUMBER TO DELETE, N/P = NEXT/PREVIOUS PAGE, ENTER = MENU: "

/* 1 if text is the letter c (upper case), in either case. */
static int is_key(const char *text, char c)
{
    return toupper((unsigned char) text[0]) == c && text[1] == '\0';
}

/*
 * Options 3 and 4: the tasks of one type by number, a page at a time.
 * Under each page a task number can be typed to delete that task
 * (after Y/N), N or P to change page, or Enter to go back to the
 * menu. Returns 0 if the program must end.
 */
static int view(App *app, TaskType type)
{
    const char *title = type == TASK_GENERAL ? "GENERAL TASKS"
        : "SPECIFIC TASKS";
    const Task **rows;
    size_t page = 0;
    MsgKind kind = MSG_NONE;
    char msg[SCREEN_WIDTH];
    char text[SCREEN_WIDTH];
    char answer[INPUT_LINE_SIZE];

    /* the list only gets shorter here */
    rows = (const Task **) malloc((app->list.count + 1) * sizeof *rows);
    if (rows == NULL) {
        set_message(app, MSG_ERROR,
                    store_status_text(STORE_ERR_MEMORY));
        return 1;
    }
    msg[0] = '\0';
    for (;;) {
        size_t count = 0, pages, first, shown, i;
        int last;
        InputStatus status;
        StoreStatus result;
        const Task *task;
        long id;

        /* Again at every turn: a deletion changes the list. */
        for (i = 0; i < app->list.count; i++) {
            if (app->list.items[i].type == type) {
                rows[count++] = &app->list.items[i];
            }
        }
        qsort((void *) rows, count, sizeof *rows, by_number);
        pages = count == 0 ? 1
            : (count + APP_PAGE_SIZE - 1) / APP_PAGE_SIZE;
        if (page >= pages) {
            page = pages - 1;   /* the last page was emptied */
        }
        first = page * APP_PAGE_SIZE;
        shown = count - first < APP_PAGE_SIZE ? count - first
            : APP_PAGE_SIZE;
        last = page + 1 == pages;

        screen_clear(&app->screen);
        if (pages > 1) {
            sprintf(text, "%s (PAGE %lu OF %lu)", title,
                    (unsigned long) page + 1, (unsigned long) pages);
            screen_title(&app->screen, text);
        } else {
            screen_title(&app->screen, title);
        }
        screen_line(&app->screen, "SORTED BY TASK NUMBER");
        screen_newline(&app->screen);
        if (count == 0) {
            screen_line(&app->screen, "NO TASKS");
        } else {
            screen_task_table(&app->screen, type, rows + first, shown);
        }
        screen_newline(&app->screen);
        if (last) {
            sprintf(text, "TOTAL TASKS: %lu", (unsigned long) count);
            screen_line(&app->screen, text);
        }
        /* no blank line before it: a full page is 24 lines */
        screen_message(&app->screen, kind, msg);
        screen_prompt_centered(&app->screen,
                               count == 0 ? "PRESS ENTER TO RETURN"
                               : pages > 1 ? PROMPT_PAGES
                               : PROMPT_ONE_PAGE);
        status = read_answer(app, answer, sizeof answer);
        if (status == INPUT_EOF || status == INPUT_ERROR) {
            free((void *) rows);
            return 0;
        }
        kind = MSG_NONE;
        msg[0] = '\0';

        if (count == 0 || (status == INPUT_OK && answer[0] == '\0')) {
            break;
        }
        if (status == INPUT_OK && pages > 1 && is_key(answer, 'N')) {
            if (last) {
                kind = MSG_WARNING;
                strcpy(msg, "THIS IS THE LAST PAGE");
            } else {
                page++;
            }
            continue;
        }
        if (status == INPUT_OK && pages > 1 && is_key(answer, 'P')) {
            if (page == 0) {
                kind = MSG_WARNING;
                strcpy(msg, "THIS IS THE FIRST PAGE");
            } else {
                page--;
            }
            continue;
        }
        if (status != INPUT_OK || !parse_task_number(answer, &id)) {
            kind = MSG_ERROR;
            strcpy(msg, pages > 1
                   ? "TYPE A TASK NUMBER, N, P OR ENTER"
                   : "TYPE A TASK NUMBER, OR PRESS ENTER");
            continue;
        }
        task = task_list_find(&app->list, id);
        if (task == NULL || task->type != type) {
            kind = MSG_ERROR;
            sprintf(msg, "NO %s TASK %ld", task_type_name(type), id);
            continue;
        }
        if (app->list.read_only) {
            kind = MSG_ERROR;
            strcpy(msg, store_status_text(STORE_ERR_READ_ONLY));
            continue;
        }
        switch (confirm_delete(app, task)) {
        case -1:
            free((void *) rows);
            return 0;
        case 0:
            kind = MSG_WARNING;
            strcpy(msg, "DELETE CANCELLED");
            break;
        default:
            result = store_delete_and_save(app->path, &app->list, id);
            if (result == STORE_OK) {
                kind = MSG_INFO;
                sprintf(msg, "TASK %ld DELETED", id);
            } else {
                kind = MSG_ERROR;
                strcpy(msg, store_status_text(result));
            }
            break;
        }
    }
    free((void *) rows);
    set_message(app, MSG_NONE, "");
    return 1;
}

/* ---- Menu -------------------------------------------------------- */

static void draw_menu(App *app)
{
    static const char *const options[] = {
        "",
        "1. ASSIGN GENERAL TASK",
        "2. ASSIGN SPECIFIC TASK",
        "3. VIEW GENERAL TASKS",
        "4. VIEW SPECIFIC TASKS",
        "",
        "0. EXIT",
        ""
    };
    char date[DATE_TEXT_SIZE];

    screen_clear(&app->screen);
    screen_newline(&app->screen);
    screen_box(&app->screen, "TASK MANAGER",
               date_to_display(&app->today, date),
               options, sizeof options / sizeof options[0]);
    screen_newline(&app->screen);
    screen_message(&app->screen, app->msg_kind, app->msg);
    screen_newline(&app->screen);
    screen_prompt_centered(&app->screen, "OPTION: ");
}

PUBLIC int app_run(FILE *in, FILE *out, int ansi, int echo,
                   const char *path, const char *backup,
                   const Date *today)
{
    App app;
    char answer[INPUT_LINE_SIZE];
    int running = 1;

    app.in = in;
    screen_init(&app.screen, out, ansi, echo);
    app.path = path;
    app.today = *today;
    task_list_init(&app.list);
    set_message(&app, MSG_NONE, "");

    if (!load(&app, backup)) {
        screen_flush(&app.screen);
        task_list_free(&app.list);
        return 1;
    }

    while (running) {
        InputStatus status;
        int option;

        draw_menu(&app);
        status = read_answer(&app, answer, sizeof answer);
        if (status == INPUT_EOF || status == INPUT_ERROR) {
            break;
        }
        set_message(&app, MSG_NONE, "");
        if (status == INPUT_OK && answer[0] == '\0') {
            /* as in the original, an empty answer just asks again */
            continue;
        }
        if (status != INPUT_OK
            || !input_parse_option(answer, 0, 4, &option)) {
            set_message(&app, MSG_ERROR,
                        "INVALID OPTION: TYPE A NUMBER FROM 0 TO 4");
            continue;
        }
        switch (option) {
        case 1: running = assign(&app, TASK_GENERAL);  break;
        case 2: running = assign(&app, TASK_SPECIFIC); break;
        case 3: running = view(&app, TASK_GENERAL);    break;
        case 4: running = view(&app, TASK_SPECIFIC);   break;
        default: running = 0;                          break;
        }
    }

    screen_clear(&app.screen);
    screen_line(&app.screen, "GOODBYE.");
    screen_flush(&app.screen);
    task_list_free(&app.list);
    return 0;
}
