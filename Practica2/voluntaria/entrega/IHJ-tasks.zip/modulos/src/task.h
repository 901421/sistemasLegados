/*
 * task.h - a task and its record in tasks.dat.
 *
 * Pure functions, no I/O. ANSI C89.
 *
 * Record format: one task per record, every field in fixed columns,
 * so a task always fits in the 80-byte records of MUSIC/SP and the
 * file can be written with any text editor. Columns, from 1:
 *
 *   1-4    task number, 4 digits with leading zeros
 *   6      type: G (general) or S (specific)
 *   8-17   date, YYYY-MM-DD
 *   19-38  name, padded with blanks (blank for general tasks)
 *   40-79  description
 *
 *   0000 G 2026-09-28                      Buy milk
 *   0003 S 2026-10-01 Imad                 Review report
 *
 * Columns 5, 7, 18 and 39 are blank. Columns count characters, not
 * bytes, so a UTF-8 "ñ" on Linux takes one column like on MUSIC/SP.
 * Texts are stored as they are: no character needs escaping.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef TASK_H
#define TASK_H

#include "public.h"

#include <stddef.h>
#include "date.h"

/*
 * Text limits, counted in characters as the user sees them. TASK_UTF8 =
 * 1 counts UTF-8 characters (Linux). On MUSIC/SP the text is EBCDIC,
 * one byte per character, and TASK_UTF8 must be 0: EBCDIC letters live
 * in 0x81-0xA9 and would be taken for UTF-8 continuation bytes.
 */
#ifndef TASK_UTF8
#define TASK_UTF8 1
#endif

#define TASK_NAME_MAX 20
#define TASK_DESC_MAX 40
#define TASK_ID_MAX   9999L         /* 4 digits, columns 1-4 */

/* Sizes in bytes: up to 4 per UTF-8 character, plus '\0'. */
#define TASK_NAME_SIZE (TASK_NAME_MAX * 4 + 1)
#define TASK_DESC_SIZE (TASK_DESC_MAX * 4 + 1)

/* Columns (from 0) where each field starts, and the record width in
   characters: 79, so it fits in 80. */
#define TASK_COL_TYPE 5
#define TASK_COL_DATE 7
#define TASK_COL_NAME 18
#define TASK_COL_DESC 39
#define TASK_RECORD_CHARS (TASK_COL_DESC + TASK_DESC_MAX)

/* Longest record in bytes: up to 4 per character in the texts, plus
   '\0'. */
#define TASK_LINE_SIZE (TASK_COL_NAME + TASK_NAME_SIZE - 1 + 1 \
                        + TASK_DESC_SIZE - 1 + 1)

typedef enum {
    TASK_GENERAL,
    TASK_SPECIFIC
} TaskType;

typedef struct {
    long id;
    TaskType type;
    Date date;
    char name[TASK_NAME_SIZE];          /* empty for general tasks */
    char description[TASK_DESC_SIZE];
} Task;

typedef enum {
    TEXT_OK = 0,
    TEXT_EMPTY,         /* empty or only blanks */
    TEXT_TOO_LONG,      /* more characters than allowed */
    TEXT_BAD_CHAR       /* control character (tab, newline...) */
} TextStatus;

typedef enum {
    LINE_OK = 0,
    LINE_BAD_FIELDS,    /* too short, or a blank column not blank */
    LINE_BAD_ID,
    LINE_BAD_TYPE,
    LINE_BAD_DATE,
    LINE_BAD_NAME,
    LINE_BAD_DESCRIPTION
} LineStatus;

/* "GENERAL" or "SPECIFIC" (the record only keeps G or S). */
PUBLIC const char *task_type_name(TaskType type);

/* Characters in text (UTF-8 aware when TASK_UTF8 is 1). */
PUBLIC size_t task_text_length(const char *text);

/* Checks a name or description typed by the user: at most max_chars
   characters and max_chars * 4 bytes. */
PUBLIC TextStatus task_check_text(const char *text, size_t max_chars);

/* Cuts text to max_chars characters and max_chars * 4 bytes, never
   in the middle of a UTF-8 character, and drops the blanks left at
   the end. Returns 1 if something was cut. */
PUBLIC int task_truncate_text(char *text, size_t max_chars);

/* LINE_OK if every field is valid, else the first bad field. */
PUBLIC LineStatus task_validate(const Task *task);

/*
 * Writes the record for task into buf (size bytes, TASK_LINE_SIZE is
 * always enough), without blanks after the description. Returns 1 on
 * success, 0 if the task is invalid or buf is too small.
 */
PUBLIC int task_format_line(const Task *task, char *buf, size_t size);

/* Reads one record, without its newline and without the blanks after
   the text (MUSIC/SP pads records with them). A missing name or
   description reads as blank. *out is only written when the result
   is LINE_OK. */
PUBLIC LineStatus task_parse_line(const char *line, Task *out);

#endif
