/*
 * screen.c - see screen.h.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <string.h>
#include "screen.h"
#include "date.h"

/* Box: 40 columns inside, 42 with the borders, centered in 80. */
#define BOX_INNER 40
#define BOX_LEFT  ((SCREEN_WIDTH - BOX_INNER - 2) / 2)

/* Table columns (characters). */
#define COL_ID   4
#define COL_DATE 10
#define GAP      "  "

#define ANSI_RESET   "\033[0m"
#define ANSI_BOLD    "\033[1m"
#define ANSI_INFO    "\033[1;32m"
#define ANSI_WARNING "\033[1;33m"
#define ANSI_ERROR   "\033[1;37;41m"
#define ANSI_CLEAR   "\033[2J\033[H"

/* MUSIC/SP takes the first character of every line as a carriage
   control: a blank for normal spacing, hex 70 ("Erase Screen") to
   clear the 3270 screen first. Others have meanings of their own
   ('-' triple spacing, '1' new page...). The single-file build sets
   SCREEN_ERASE_CHAR there; elsewhere lines are written as they are. */
#ifdef SCREEN_ERASE_CHAR
#define CARRIAGE_CONTROL 1
#else
#define CARRIAGE_CONTROL 0
#define SCREEN_ERASE_CHAR ' '
#endif

PUBLIC void screen_init(Screen *s, FILE *out, int ansi, int echo)
{
    s->out = out;
    s->ansi = ansi;
    s->echo = echo;
    /* a terminal of MUSIC/SP: no ANSI, and it shows what is typed */
    s->carriage = CARRIAGE_CONTROL && !ansi && !echo;
    s->buffering = 0;
    s->page_len = 0;
}

/* Rows of the 3270 screen that a program can use on MUSIC/SP; the
   last three hold the tab line, the input line and the status. */
#define SCREEN_ROWS 40

/* In carriage mode a screen is kept here from screen_clear until it
   is complete (screen_flush), to center it in SCREEN_ROWS. */
#define PAGE_SIZE 8192
static char page[PAGE_SIZE];

static void out_char(Screen *s, int c)
{
    if (s->buffering) {
        if (s->page_len < PAGE_SIZE) {
            page[s->page_len++] = (char) c;
            return;
        }
        screen_flush(s);    /* too big to center: as it is */
    }
    putc(c, s->out);
}

static void out_str(Screen *s, const char *text)
{
    while (*text != '\0') {
        out_char(s, *text++);
    }
}

PUBLIC void screen_flush(Screen *s)
{
    if (s->buffering) {
        /* the prompt line, and the one MUSIC/SP adds for the answer */
        size_t rows = 2;
        size_t pad;
        size_t i;

        s->buffering = 0;
        for (i = 0; i < s->page_len; i++) {
            if (page[i] == '\n') {
                rows++;
            }
        }
        pad = rows < SCREEN_ROWS ? (SCREEN_ROWS - rows) / 2 : 0;
        /* "Erase Screen", in an empty first row (the original tareas.c
           had it commented out in clrscr), then the rest of the top
           margin */
        putc(SCREEN_ERASE_CHAR, s->out);
        putc('\n', s->out);
        for (i = 1; i < pad; i++) {
            fputs(" \n", s->out);
        }
        fwrite(page, 1, s->page_len, s->out);
    }
    fflush(s->out);
}

static void spaces(Screen *s, size_t n)
{
    while (n-- > 0) {
        out_char(s, ' ');
    }
}

/* Starts a line: its carriage control, if any, then n spaces. */
static void line_start(Screen *s, size_t n)
{
    if (s->carriage) {
        out_char(s, ' ');
    }
    spaces(s, n);
}

static void repeat_char(Screen *s, char c, size_t n)
{
    while (n-- > 0) {
        out_char(s, c);
    }
}

static void style(Screen *s, const char *code)
{
    if (s->ansi) {
        out_str(s, code);
    }
}

/* Writes text padded with spaces to width characters (not bytes). */
static void padded(Screen *s, const char *text, size_t width)
{
    size_t len = task_text_length(text);

    out_str(s, text);
    if (len < width) {
        spaces(s, width - len);
    }
}

/* Left margin that centers something of width characters. */
static size_t center_margin(size_t width)
{
    return width < SCREEN_WIDTH ? (SCREEN_WIDTH - width) / 2 : 0;
}

PUBLIC void screen_newline(Screen *s)
{
    out_char(s, '\n');
}

PUBLIC void screen_clear(Screen *s)
{
    if (s->ansi) {
        out_str(s, ANSI_CLEAR);
    } else if (s->carriage) {
        /* Kept until it is complete; screen_flush erases the 3270
           screen and writes it centered. */
        s->buffering = 1;
        s->page_len = 0;
    } else {
        out_char(s, '\n');
    }
}

PUBLIC void screen_box(Screen *s, const char *title, const char *corner,
                       const char *const *lines, size_t count)
{
    /* with a space on each side */
    size_t title_len = strlen(title) + 2;
    size_t left_dashes = (BOX_INNER - title_len) / 2;
    size_t i;

    /* +------ TITLE ------+ */
    line_start(s, BOX_LEFT);
    out_char(s, '+');
    repeat_char(s, '-', left_dashes);
    style(s, ANSI_BOLD);
    out_char(s, ' ');
    out_str(s, title);
    out_char(s, ' ');
    style(s, ANSI_RESET);
    repeat_char(s, '-', BOX_INNER - left_dashes - title_len);
    out_str(s, "+\n");

    if (corner != NULL) {
        line_start(s, BOX_LEFT);
        out_char(s, '|');
        spaces(s, BOX_INNER - strlen(corner) - 2);
        out_str(s, corner);
        out_str(s, "  |\n");
    }
    for (i = 0; i < count; i++) {
        line_start(s, BOX_LEFT);
        out_str(s, "|   ");
        padded(s, lines[i], BOX_INNER - 3);
        out_str(s, "|\n");
    }

    line_start(s, BOX_LEFT);
    out_char(s, '+');
    repeat_char(s, '-', BOX_INNER);
    out_str(s, "+\n");
}

PUBLIC void screen_message(Screen *s, MsgKind kind, const char *text)
{
    const char *code = kind == MSG_ERROR ? ANSI_ERROR
                     : kind == MSG_WARNING ? ANSI_WARNING : ANSI_INFO;

    if (kind == MSG_NONE || text == NULL || text[0] == '\0') {
        out_char(s, '\n');
        return;
    }
    if (!s->ansi) {
        screen_line(s, text);
        return;
    }
    /* A space each side, so the red background reads as a bar. */
    line_start(s, center_margin(task_text_length(text) + 2));
    style(s, code);
    out_char(s, ' ');
    out_str(s, text);
    out_char(s, ' ');
    style(s, ANSI_RESET);
    out_char(s, '\n');
}

PUBLIC void screen_prompt(Screen *s, const char *label)
{
    line_start(s, BOX_LEFT);
    style(s, ANSI_BOLD);
    out_str(s, label);
    style(s, ANSI_RESET);
    screen_flush(s);
}

PUBLIC void screen_prompt_centered(Screen *s, const char *label)
{
    /* +1: the cursor */
    line_start(s, center_margin(strlen(label) + 1));
    style(s, ANSI_BOLD);
    out_str(s, label);
    style(s, ANSI_RESET);
    screen_flush(s);
}

PUBLIC void screen_field(Screen *s, const char *label,
                         size_t label_width, const char *value)
{
    line_start(s, BOX_LEFT);
    style(s, ANSI_BOLD);
    padded(s, label, label_width);
    style(s, ANSI_RESET);
    if (value != NULL) {
        out_str(s, value);
        out_char(s, '\n');
    } else {
        screen_flush(s);
    }
}

PUBLIC void screen_echo(Screen *s, const char *answer)
{
    if (s->echo) {
        out_str(s, answer);
        out_char(s, '\n');
    }
}

PUBLIC void screen_title(Screen *s, const char *text)
{
    line_start(s, center_margin(strlen(text)));
    style(s, ANSI_BOLD);
    out_str(s, text);
    style(s, ANSI_RESET);
    out_char(s, '\n');
}

PUBLIC void screen_line(Screen *s, const char *text)
{
    line_start(s, center_margin(task_text_length(text)));
    out_str(s, text);
    out_char(s, '\n');
}

PUBLIC void screen_task_table(Screen *s, TaskType type,
                              const Task *const *rows, size_t count)
{
    int specific = type == TASK_SPECIFIC;
    size_t width = COL_ID + 2 + COL_DATE + 2 + TASK_DESC_MAX
                   + (specific ? TASK_NAME_MAX + 1 : 0);
    size_t margin = center_margin(width);
    char date[DATE_TEXT_SIZE];
    char number[24];
    size_t i;

    /* Header and underline */
    line_start(s, margin);
    style(s, ANSI_BOLD);
    padded(s, "TASK", COL_ID);
    out_str(s, GAP);
    padded(s, "DATE", COL_DATE);
    out_str(s, GAP);
    if (specific) {
        padded(s, "NAME", TASK_NAME_MAX);
        out_char(s, ' ');
    }
    out_str(s, "DESCRIPTION");
    style(s, ANSI_RESET);
    out_char(s, '\n');

    line_start(s, margin);
    repeat_char(s, '-', COL_ID);
    out_str(s, GAP);
    repeat_char(s, '-', COL_DATE);
    out_str(s, GAP);
    if (specific) {
        repeat_char(s, '-', TASK_NAME_MAX);
        out_char(s, ' ');
    }
    repeat_char(s, '-', TASK_DESC_MAX);
    out_char(s, '\n');

    for (i = 0; i < count; i++) {
        const Task *t = rows[i];

        line_start(s, margin);
        sprintf(number, "%*ld", COL_ID, t->id);
        out_str(s, number);
        out_str(s, GAP);
        out_str(s, date_to_display(&t->date, date));
        out_str(s, GAP);
        if (specific) {
            padded(s, t->name, TASK_NAME_MAX);
            out_char(s, ' ');
        }
        out_str(s, t->description);
        out_char(s, '\n');
    }
}
