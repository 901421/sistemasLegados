/*
 * date.h - calendar dates for the task manager.
 *
 * Pure functions (no I/O, no clock) except date_today(), so every rule
 * can be unit tested. ANSI C89.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef DATE_H
#define DATE_H

#include "public.h"

#define DATE_MIN_YEAR 1900
#define DATE_MAX_YEAR 2999

/* Room for "DD/MM/YYYY" or "YYYY-MM-DD" plus the terminating '\0'. */
#define DATE_TEXT_SIZE 11

typedef struct {
    int year;
    int month;  /* 1..12 */
    int day;    /* 1..31 */
} Date;

typedef enum {
    DATE_OK = 0,
    DATE_ERR_FORMAT,    /* text does not match any accepted format */
    DATE_ERR_INVALID    /* right format, but that day does not exist */
} DateStatus;

PUBLIC int date_is_leap(int year);

/* Days in that month, or 0 if the month is out of range. */
PUBLIC int date_days_in_month(int year, int month);

/* 1 if the date exists and DATE_MIN_YEAR <= year <= DATE_MAX_YEAR. */
PUBLIC int date_is_valid(const Date *d);

/*
 * Parses what the user types. Accepted formats:
 *   D/M/YYYY, DD/MM/YYYY (day and month with 1 or 2 digits)
 *   D/M, DD/MM           (year = default_year)
 *   DDMM                 (exactly 4 digits, year = default_year)
 * *out is only written when the result is DATE_OK.
 */
PUBLIC DateStatus date_parse(const char *text, int default_year,
                             Date *out);

/* Stored form YYYY-MM-DD. Returns DATE_OK or a DATE_ERR_ code. */
PUBLIC DateStatus date_from_iso(const char *text, Date *out);

/* buf must hold DATE_TEXT_SIZE chars. Both return buf. */
PUBLIC char *date_to_iso(const Date *d, char *buf);
PUBLIC char *date_to_display(const Date *d, char *buf);

/* <0, 0 or >0, like strcmp. */
PUBLIC int date_compare(const Date *a, const Date *b);

/* Today's local date. 1 on success, 0 if there is no clock. */
PUBLIC int date_today(Date *out);

#endif
