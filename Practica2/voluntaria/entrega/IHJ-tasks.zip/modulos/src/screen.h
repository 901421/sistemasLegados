/*
 * screen.h - everything the user sees, on an 80-column screen.
 *
 * Two independent settings:
 *   ansi  colours and clear-screen codes, for a terminal; without
 *         them the same text is written plainly (MUSIC/SP, tests)
 *   echo  each answer is written back, so a run read from a file
 *         looks like the screen (tests). A terminal, and the 3270
 *         line mode of MUSIC/SP, already show what is typed.
 * Only this module knows about escape codes. ANSI C89.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#ifndef SCREEN_H
#define SCREEN_H

#include "public.h"

#include <stdio.h>
#include <stddef.h>
#include "task.h"

#define SCREEN_WIDTH 80

typedef enum {
    MSG_NONE,           /* empty status line */
    MSG_INFO,           /* green: something was done */
    MSG_WARNING,        /* yellow: accepted, but take note */
    /* white on red, as in the COBOL screens of practice 1 */
    MSG_ERROR
} MsgKind;

typedef struct {
    FILE *out;
    int ansi;   /* colours and clear-screen codes */
    /* write back each answer (input from a file, not a terminal) */
    int echo;
    int carriage;   /* lines start with a carriage control (MUSIC/SP) */
    int buffering;  /* keeping the screen to center it (MUSIC/SP) */
    size_t page_len;
} Screen;

PUBLIC void screen_init(Screen *s, FILE *out, int ansi, int echo);

/*
 * Clears the screen (ANSI) or leaves a blank line (plain). Built with
 * SCREEN_ERASE_CHAR (MUSIC/SP), plain mode without echo starts every
 * line with a carriage control, and the screen is kept until
 * screen_flush, which erases the 3270 screen and writes it centered.
 */
PUBLIC void screen_clear(Screen *s);

/* Writes out what is pending; called before every read. */
PUBLIC void screen_flush(Screen *s);

/* Ends a line (an empty one if nothing was written on it). */
PUBLIC void screen_newline(Screen *s);

/*
 * Centered box: a title in the top border, an optional text
 * right-aligned in the first row (the date in the menu) and one row per
 * entry of lines.
 */
PUBLIC void screen_box(Screen *s, const char *title, const char *corner,
                const char *const *lines, size_t count);

/* Centered status line in its colour; empty line for MSG_NONE. */
PUBLIC void screen_message(Screen *s, MsgKind kind, const char *text);

/* Prompt with no line end, at the left edge of the box or centered. */
PUBLIC void screen_prompt(Screen *s, const char *label);
PUBLIC void screen_prompt_centered(Screen *s, const char *label);

/*
 * A form field at the left edge of the box: the label padded to
 * label_width and its value with a line end, or, when value is NULL,
 * the label alone with the cursor left after it.
 */
PUBLIC void screen_field(Screen *s, const char *label,
                         size_t label_width, const char *value);

/* With echo on, writes back what was read (files do not echo). */
PUBLIC void screen_echo(Screen *s, const char *answer);

/* Centered title line (bold in ANSI). */
PUBLIC void screen_title(Screen *s, const char *text);

/* Table of tasks of one type: header and one row per task, centered. */
PUBLIC void screen_task_table(Screen *s, TaskType type,
                              const Task *const *rows, size_t count);

/* Plain centered line. */
PUBLIC void screen_line(Screen *s, const char *text);

#endif
