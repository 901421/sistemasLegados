/*
 * store.c - see store.h.
 *
 * Author: Imad Habib Jali (NIP 901421)
 */
#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "store.h"

#define FIRST_CAPACITY 16
#define TMP_SUFFIX ".tmp"

/* errno that fopen leaves when the file does not exist. POSIX says
   ENOENT. Waterloo C 3.2 on MUSIC/SP leaves 30 ("Permanent I/O
   error"), measured on 2026-10-07; the single-file build sets it. */
#ifndef STORE_NO_FILE_ERRNO
#ifdef ENOENT
#define STORE_NO_FILE_ERRNO ENOENT
#endif
#endif

/* Control record that keeps the number for the next task, so a
   number is never given twice, even after its task is deleted. It is
   the first record of the file: "*NEXT 0040". */
#define CONTROL_PREFIX "*NEXT "

PUBLIC void task_list_init(TaskList *list)
{
    list->items = NULL;
    list->count = 0;
    list->capacity = 0;
    list->next_id = 0;      /* the original numbered from TASK 0 */
    list->read_only = 0;
}

PUBLIC void task_list_free(TaskList *list)
{
    free(list->items);
    task_list_init(list);
}

/* Makes room for one more task. Returns 0 if out of memory. */
static int grow(TaskList *list)
{
    size_t capacity;
    Task *items;

    if (list->count < list->capacity) {
        return 1;
    }
    capacity = list->capacity == 0 ? FIRST_CAPACITY
        : list->capacity * 2;
    /* INT_MAX and not (size_t) -1: in Waterloo C 3.2 size_t is signed,
       so (size_t) -1 is -1 there and no capacity would fit. */
    if (capacity < list->capacity
        || capacity > (size_t) (INT_MAX / sizeof(Task))) {
        return 0;
    }
    items = (Task *) realloc(list->items, capacity * sizeof(Task));
    if (items == NULL) {
        return 0;
    }
    list->items = items;
    list->capacity = capacity;
    return 1;
}

PUBLIC StoreStatus task_list_add(TaskList *list, Task *task)
{
    long old_id = task->id;

    if (list->next_id > TASK_ID_MAX) {
        return STORE_ERR_FULL;
    }
    task->id = list->next_id;
    if (task_validate(task) != LINE_OK) {
        task->id = old_id;
        return STORE_ERR_INVALID;
    }
    if (!grow(list)) {
        task->id = old_id;
        return STORE_ERR_MEMORY;
    }
    list->items[list->count++] = *task;
    list->next_id++;
    return STORE_OK;
}

PUBLIC const Task *task_list_find(const TaskList *list, long id)
{
    size_t i;

    for (i = 0; i < list->count; i++) {
        if (list->items[i].id == id) {
            return &list->items[i];
        }
    }
    return NULL;
}

static int has_id(const TaskList *list, long id)
{
    return task_list_find(list, id) != NULL;
}

static void note_skip(LoadReport *report, long line, SkipReason reason)
{
    if (report->listed < STORE_REPORT_MAX) {
        report->lines[report->listed].line = line;
        report->lines[report->listed].reason = reason;
        report->listed++;
    }
    report->skipped++;
}

static SkipReason skip_reason(LineStatus status)
{
    switch (status) {
    case LINE_BAD_ID:          return SKIP_BAD_ID;
    case LINE_BAD_TYPE:        return SKIP_BAD_TYPE;
    case LINE_BAD_DATE:        return SKIP_BAD_DATE;
    case LINE_BAD_NAME:        return SKIP_BAD_NAME;
    case LINE_BAD_DESCRIPTION: return SKIP_BAD_DESCRIPTION;
    default:                   return SKIP_BAD_FIELDS;
    }
}

/* Byte-for-byte copy. Returns 1 on success. */
static int copy_file(const char *from, const char *to)
{
    char buf[4096];
    size_t n;
    int ok = 1;
    FILE *in, *out;

    in = fopen(from, "rb");
    if (in == NULL) {
        return 0;
    }
    out = fopen(to, "wb");
    if (out == NULL) {
        fclose(in);
        return 0;
    }
    while ((n = fread(buf, 1, sizeof buf, in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) {
            ok = 0;
            break;
        }
    }
    if (ferror(in)) {
        ok = 0;
    }
    fclose(in);
    if (fclose(out) != 0) {
        ok = 0;
    }
    return ok;
}

/*
 * Reads the next line into buf (size bytes) without its end ("\n" or
 * "\r\n") and without the blanks after the text: MUSIC/SP pads its
 * 80-byte records with them, and a text editor may leave some.
 * Returns 0 at the end of the file, 1 with the line in buf, or 2 if
 * the text did not fit (the line is skipped).
 */
static int read_line(FILE *in, char *buf, size_t size)
{
    size_t n;
    int c;
    int too_long = 0;

    if (fgets(buf, (int) size, in) == NULL) {
        return 0;
    }
    n = strlen(buf);
    if (n > 0 && buf[n - 1] == '\n') {
        n--;
    } else {
        /* Did not fit: the rest may only be blanks. */
        while ((c = getc(in)) != '\n' && c != EOF) {
            if (c != ' ' && c != '\r') {
                too_long = 1;
            }
        }
    }
    while (n > 0 && (buf[n - 1] == '\r' || buf[n - 1] == ' ')) {
        n--;
    }
    buf[n] = '\0';
    return too_long ? 2 : 1;
}

/* "*NEXT nnnn": 1 to 5 digits, up to TASK_ID_MAX + 1 (no numbers
   left). Returns 1 and the number in *next if line is one. */
static int parse_control(const char *line, long *next)
{
    const char *p = line + strlen(CONTROL_PREFIX);
    long value = 0;
    int digits = 0;

    if (strncmp(line, CONTROL_PREFIX, strlen(CONTROL_PREFIX)) != 0) {
        return 0;
    }
    for (; *p >= '0' && *p <= '9' && digits < 6; p++, digits++) {
        value = value * 10 + (*p - '0');
    }
    if (*p != '\0' || digits == 0 || digits > 5
        || value > TASK_ID_MAX + 1) {
        return 0;
    }
    *next = value;
    return 1;
}

PUBLIC StoreStatus store_load(const char *path, const char *backup_path,
                              TaskList *list, LoadReport *report)
{
    char buf[TASK_LINE_SIZE + 1];
    long line_number = 0;
    long max_id = -1;
    long next = 0;
    FILE *in;
    int got;

    memset(report, 0, sizeof *report);
    errno = 0;
    in = fopen(path, "r");
    if (in == NULL) {
#ifdef STORE_NO_FILE_ERRNO
        /* Where it is not known (ENOENT is POSIX, not C89), any
           failure counts as "no file". */
        if (errno != STORE_NO_FILE_ERRNO) {
            return STORE_ERR_OPEN;
        }
#endif
        return STORE_OK;
    }

    for (;;) {
        Task task;
        LineStatus status;

        got = read_line(in, buf, sizeof buf);
        if (got == 0) {
            break;
        }
        line_number++;
        if (got == 2) {
            note_skip(report, line_number, SKIP_TOO_LONG);
            continue;
        }
        if (buf[0] == '\0') {
            continue;
        }
        if (buf[0] == '*') {
            long value;

            if (!parse_control(buf, &value)) {
                note_skip(report, line_number, SKIP_BAD_CONTROL);
            } else if (value > next) {
                next = value;
            }
            continue;
        }

        status = task_parse_line(buf, &task);
        if (status != LINE_OK) {
            note_skip(report, line_number, skip_reason(status));
        } else if (has_id(list, task.id)) {
            note_skip(report, line_number, SKIP_DUPLICATE_ID);
        } else if (!grow(list)) {
            fclose(in);
            task_list_free(list);
            return STORE_ERR_MEMORY;
        } else {
            list->items[list->count++] = task;
            if (task.id > max_id) {
                max_id = task.id;
            }
        }
    }
    if (ferror(in)) {
        fclose(in);
        task_list_free(list);
        return STORE_ERR_READ;
    }
    fclose(in);

    /* Without a control record (a file written by hand), the next
       number is the highest one + 1. */
    list->next_id = max_id + 1 > next ? max_id + 1 : next;
    if (report->skipped > 0) {
        if (!copy_file(path, backup_path)) {
            list->read_only = 1;
            return STORE_ERR_BACKUP;
        }
        report->backup_made = 1;
    }
    return STORE_OK;
}

PUBLIC StoreStatus store_save(const char *path, const TaskList *list)
{
    char line[TASK_LINE_SIZE];
    char *tmp;
    FILE *out;
    size_t i;
    int ok = 1;

    if (list->read_only) {
        return STORE_ERR_READ_ONLY;
    }
    tmp = (char *) malloc(strlen(path) + sizeof TMP_SUFFIX);
    if (tmp == NULL) {
        return STORE_ERR_MEMORY;
    }
    strcpy(tmp, path);
    strcat(tmp, TMP_SUFFIX);

    out = fopen(tmp, "w");
    if (out == NULL) {
        free(tmp);
        return STORE_ERR_WRITE;
    }
    if (fprintf(out, "%s%04ld\n", CONTROL_PREFIX, list->next_id) < 0) {
        ok = 0;
    }
    for (i = 0; i < list->count && ok; i++) {
        if (!task_format_line(&list->items[i], line, sizeof line)
            || fputs(line, out) == EOF || putc('\n', out) == EOF) {
            ok = 0;
        }
    }
    if (fclose(out) != 0) {
        ok = 0;
    }
    if (!ok) {
        remove(tmp);
        free(tmp);
        return STORE_ERR_WRITE;
    }

    /* POSIX rename replaces path atomically; on Windows it fails if
       path exists. */
    if (rename(tmp, path) != 0) {
        remove(path);
        if (rename(tmp, path) != 0) {
            /* the data is still in path.tmp: do not delete it */
            free(tmp);
            return STORE_ERR_WRITE;
        }
    }
    free(tmp);
    return STORE_OK;
}

PUBLIC StoreStatus store_add_and_save(const char *path, TaskList *list,
                                      Task *task)
{
    StoreStatus status;

    if (list->read_only) {
        return STORE_ERR_READ_ONLY;
    }
    status = task_list_add(list, task);
    if (status != STORE_OK) {
        return status;
    }
    status = store_save(path, list);
    if (status != STORE_OK) {
        list->count--;      /* not on disk, so not in the list either */
        list->next_id--;
    }
    return status;
}

PUBLIC StoreStatus store_delete_and_save(const char *path,
                                         TaskList *list, long id)
{
    const Task *found;
    Task removed;
    size_t index;
    StoreStatus status;

    if (list->read_only) {
        return STORE_ERR_READ_ONLY;
    }
    found = task_list_find(list, id);
    if (found == NULL) {
        return STORE_ERR_NOT_FOUND;
    }
    index = (size_t) (found - list->items);
    removed = *found;
    memmove(list->items + index, list->items + index + 1,
            (list->count - index - 1) * sizeof(Task));
    list->count--;

    status = store_save(path, list);
    if (status != STORE_OK) {
        /* still on disk, so back in the list, in its place */
        memmove(list->items + index + 1, list->items + index,
                (list->count - index) * sizeof(Task));
        list->items[index] = removed;
        list->count++;
    }
    return status;
}

PUBLIC const char *store_status_text(StoreStatus status)
{
    switch (status) {
    case STORE_OK:            return "OK";
    case STORE_ERR_OPEN:      return "CANNOT OPEN THE TASK FILE";
    case STORE_ERR_READ:      return "ERROR READING THE TASK FILE";
    case STORE_ERR_WRITE:     return "ERROR WRITING THE TASK FILE";
    case STORE_ERR_MEMORY:    return "OUT OF MEMORY";
    case STORE_ERR_BACKUP:
        return "DAMAGED FILE AND BACKUP FAILED: "
               "CHANGES WILL NOT BE SAVED";
    case STORE_ERR_READ_ONLY:
        return "CHANGES CANNOT BE SAVED (BACKUP FAILED AT START)";
    case STORE_ERR_FULL:      return "NO TASK NUMBERS LEFT";
    case STORE_ERR_INVALID:   return "INVALID TASK";
    case STORE_ERR_NOT_FOUND: return "NO TASK WITH THAT NUMBER";
    }
    return "UNKNOWN ERROR";
}

PUBLIC const char *store_skip_text(SkipReason reason)
{
    switch (reason) {
    case SKIP_BAD_FIELDS:      return "WRONG FORMAT";
    case SKIP_BAD_ID:          return "BAD TASK NUMBER";
    case SKIP_BAD_TYPE:        return "BAD TYPE";
    case SKIP_BAD_DATE:        return "BAD DATE";
    case SKIP_BAD_NAME:        return "BAD NAME";
    case SKIP_BAD_DESCRIPTION: return "BAD DESCRIPTION";
    case SKIP_DUPLICATE_ID:    return "REPEATED TASK NUMBER";
    case SKIP_TOO_LONG:        return "LINE TOO LONG";
    case SKIP_BAD_CONTROL:     return "BAD *NEXT RECORD";
    }
    return "UNKNOWN";
}
